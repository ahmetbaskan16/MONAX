import { useState, useEffect, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";

interface Plant {
  id: string;
  name: string;
  scientific: string;
  field: string;
  moisture: number;
  targetRange: string;
  isTree: boolean;
  type: "Sebze" | "Ağaç";
  temp: number;
  lastWatered: string;
  pH: number;
  ec: number;
}

interface Achievement {
  id: string;
  title: string;
  desc: string;
  icon: string;
  unlocked: boolean;
  progress: number; // percentage
}

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<"home" | "plants" | "analysis" | "settings">("home");

  // Interaction State
  const [toasts, setToasts] = useState<Array<{ id: number; message: string; type: "info" | "success" | "warning" }>>([]);
  const [retroPopup, setRetroPopup] = useState<{ title: string; desc: string; icon: string } | null>(null);
  const [profileOpen, setProfileOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [addPlantOpen, setAddPlantOpen] = useState(false);
  const [referralPopup, setReferralPopup] = useState<{ name: string; price: number; discount: number; store: string } | null>(null);
  const [selectedPlantDetails, setSelectedPlantDetails] = useState<Plant | null>(null);
  const [detailChartTab, setDetailChartTab] = useState<"humidity" | "temperature" | "ph">("humidity");
  const [isWateringDetailPlant, setIsWateringDetailPlant] = useState(false);

  // Core System States
  const [wateredTomato, setWateredTomato] = useState(false);
  const [selectedAIPlant, setSelectedAIPlant] = useState<"cilek" | "elma" | "domates" | "biber" | "portakal">("cilek");
  const [warrantyPoints, setWarrantyPoints] = useState(3); // Out of 10 for warranty +1 month
  const [wateringLoading, setWateringLoading] = useState(false);

  // Settings Toggles
  const [settingsNotif, setSettingsNotif] = useState(true);
  const [settingsAuto, setSettingsAuto] = useState(true);
  const [settingsInterval, setSettingsInterval] = useState("5 Dakika");

  // User Profile States
  const [userName, setUserName] = useState("Ahmet Yılmaz");
  const [userEmail, setUserEmail] = useState("ahmet@monax.io");
  const [editingProfile, setEditingProfile] = useState(false);
  const [editNameField, setEditNameField] = useState("Ahmet Yılmaz");
  const [editEmailField, setEditEmailField] = useState("ahmet@monax.io");

  // Interactive Settings Modals & Simulated Flows
  const [bluetoothModalOpen, setBluetoothModalOpen] = useState(false);
  const [bluetoothSearching, setBluetoothSearching] = useState(false);
  const [contractsModalOpen, setContractsModalOpen] = useState(false);

  // Initial Registered Plants
  const [activePlants, setActivePlants] = useState<Plant[]>([
    {
      id: "tomato",
      name: "Sera Domatesi",
      scientific: "Solanum lycopersicum",
      field: "Sera A · Sensör #03",
      moisture: 28,
      targetRange: "65%–85%",
      isTree: false,
      type: "Sebze",
      temp: 22,
      lastWatered: "2 gün önce",
      pH: 6.2,
      ec: 1.8,
    },
    {
      id: "pepper",
      name: "Tarla Biberi",
      scientific: "Capsicum annuum",
      field: "Tarla B · Sensör #07",
      moisture: 76,
      targetRange: "65%–85%",
      isTree: false,
      type: "Sebze",
      temp: 19,
      lastWatered: "5 saat önce",
      pH: 6.8,
      ec: 2.1,
    },
    {
      id: "apple",
      name: "Amasya Elması",
      scientific: "Malus domestica",
      field: "Bahçe C · Sensör #12",
      moisture: 55,
      targetRange: "50%–70%",
      isTree: true,
      type: "Ağaç",
      temp: 21,
      lastWatered: "1 gün önce",
      pH: 6.5,
      ec: 1.5,
    },
  ]);

  // Achievements State (Yalnızca Sponsorlu Mağaza Alımları ile Açılır!)
  const [gameAchievements, setGameAchievements] = useState<Achievement[]>([
    {
      id: "purchase_1",
      title: "İlk Sipariş",
      desc: "Sponsorlu mağazadan 1 ürün satın alındı.",
      icon: "🛍️",
      unlocked: true,
      progress: 100,
    },
    {
      id: "purchase_3",
      title: "Eko Destekçi",
      desc: "Sponsorlu mağazadan toplam 3 ürün satın alındı (%12 indirim).",
      icon: "🌱",
      unlocked: true,
      progress: 100,
    },
    {
      id: "purchase_5",
      title: "Yeşil Yatırımcı",
      desc: "Sponsorlu mağazadan toplam 5 ürün satın alındı.",
      icon: "🧪",
      unlocked: false,
      progress: 60,
    },
    {
      id: "purchase_8",
      title: "Süre Kahramanı",
      desc: "8 siparişe ulaşıldı! Garanti süresi uzamaya çok yakın.",
      icon: "🚜",
      unlocked: false,
      progress: 37.5,
    },
    {
      id: "purchase_10",
      title: "Garanti Fatihi",
      desc: "10 siparişe ulaşıp +1 Ay Akıllı Garanti kazandınız!",
      icon: "🏆",
      unlocked: false,
      progress: 30,
    },
  ]);

  // Dynamic Add Custom Plant Form State
  const [newPlantName, setNewPlantName] = useState("");
  const [newPlantField, setNewPlantField] = useState("Sera A");
  const [newPlantType, setNewPlantType] = useState<"Sebze" | "Ağaç">("Sebze");
  const [newPlantMoisture, setNewPlantMoisture] = useState(70);

  // Sound Engine
  const playRetroSynth = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      
      const now = audioCtx.currentTime;
      osc.type = "sine";
      
      // Retro pixel chiptune experience beep / level up chime
      osc.frequency.setValueAtTime(440.00, now); // A4
      osc.frequency.setValueAtTime(554.37, now + 0.08); // C#5
      osc.frequency.setValueAtTime(659.25, now + 0.16); // E5
      osc.frequency.setValueAtTime(880.00, now + 0.24); // A5
      
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
      
      osc.start(now);
      osc.stop(now + 0.7);
    } catch (e) {
      console.log("Web Audio not allowed or failed", e);
    }
  };

  // Toast Notifier Helper
  const triggerToast = (msg: string, type: "info" | "success" | "warning" = "info") => {
    const id = Date.now();
    setToasts((prev) => [...prev, { id, message: msg, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  // Generate mock chart data points dynamically for custom details popup
  const getChartPoints = (plant: Plant, tab: "humidity" | "temperature" | "ph") => {
    if (tab === "humidity") {
      const base = plant.moisture;
      return [
        { label: "12:00", val: Math.max(0, base - 8) },
        { label: "13:00", val: Math.max(0, base - 5) },
        { label: "14:00", val: Math.max(0, base - 2) },
        { label: "15:00", val: base },
        { label: "16:00", val: base },
        { label: "17:00", val: base },
      ];
    } else if (tab === "temperature") {
      const base = plant.temp;
      return [
        { label: "12:00", val: base - 2 },
        { label: "13:00", val: base - 1 },
        { label: "14:00", val: base + 1 },
        { label: "15:00", val: base },
        { label: "16:00", val: base + 2 },
        { label: "17:00", val: base },
      ];
    } else {
      const base = plant.pH;
      return [
        { label: "12:00", val: Number((base - 0.2).toFixed(1)) },
        { label: "13:00", val: Number((base - 0.1).toFixed(1)) },
        { label: "14:00", val: base },
        { label: "15:00", val: base },
        { label: "16:00", val: base },
        { label: "17:00", val: base },
      ];
    }
  };

  // Retro Chiptune Sound + Popup Helper
  const triggerRetroPopup = (title: string, desc: string, icon: string) => {
    playRetroSynth();
    setRetroPopup({ title, desc, icon });
    setTimeout(() => {
      setRetroPopup(null);
    }, 5000);
  };

  // Action: Tomato Watering Flow
  const handleWaterTomato = () => {
    if (wateredTomato) {
      triggerToast("Domates bahçeniz zaten ideal nem seviyesinde (%85) stabilize edildi.", "info");
      return;
    }
    
    setWateringLoading(true);
    triggerToast("Cihaz Bluetooth ile taranıyor... Sera A geçit vanası test ediliyor...", "info");

    setTimeout(() => {
      setWateringLoading(false);
      setWateredTomato(true);
      
      // Update tomato plant moisture state
      setActivePlants((prev) =>
        prev.map((p) => (p.id === "tomato" ? { ...p, moisture: 85, lastWatered: "Şimdi sula", pH: 6.4, ec: 1.7 } : p))
      );

      triggerToast("Sera Domatesi sulama işlemi başarıyla tamamlandı!", "success");
      playRetroSynth();
    }, 2000);
  };

  // Action: Interactive watering from Details modal
  const handleWaterDetailPlant = (plantId: string) => {
    if (isWateringDetailPlant) return;
    setIsWateringDetailPlant(true);
    triggerToast("Hücresel hat üzerinden manuel vana sinyali gönderiliyor...", "info");
    playRetroSynth();
    
    setTimeout(() => {
      setIsWateringDetailPlant(false);
      setActivePlants((prev) =>
        prev.map((p) => {
          if (p.id === plantId) {
            if (plantId === "tomato") {
              setWateredTomato(true);
            }
            return {
              ...p,
              moisture: Math.min(p.moisture + 20, 85),
              lastWatered: "Şimdi sulandı (Manuel)",
              pH: Math.min(p.pH + 0.2, 7.0),
              ec: Math.max(p.ec - 0.1, 1.5),
            };
          }
          return p;
        })
      );
      
      // Keep modal display in sync
      setSelectedPlantDetails((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          moisture: Math.min(prev.moisture + 20, 85),
          lastWatered: "Şimdi sulandı (Manuel)",
          pH: Math.min(prev.pH + 0.2, 7.0),
          ec: Math.max(prev.ec - 0.1, 1.5),
        };
      });
      
      triggerToast("Seçilen istasyonun manuel sulama periyodu başarıyla tamamlandı!", "success");
      playRetroSynth();
    }, 1500);
  };

  // Action: Add Strawberry via AI Module
  const handleAddStrawberry = () => {
    // Check if strawberry already exists
    const exists = activePlants.some((p) => p.id === "strawberry");
    if (exists) {
      triggerToast("Çilek zaten bahçenizde aktif izleme planında bulunuyor.", "warning");
      return;
    }

    const newStrawberry: Plant = {
      id: "strawberry",
      name: "Çilek (Sera Bahçesi)",
      scientific: "Fragaria × ananassa",
      field: "Sera A · Sensör #18",
      moisture: 75,
      targetRange: "70%–80%",
      isTree: false,
      type: "Sebze",
      temp: 23,
      lastWatered: "Yeni eklendi",
      pH: 5.8,
      ec: 1.6,
    };

    setActivePlants((prev) => [...prev, newStrawberry]);
    triggerToast("Fragaria × ananassa (Çilek) bahçenize eklendi! Optimum nem planı %75 olarak yapıldı.", "success");
    playRetroSynth();
  };

  // Action: Add Custom Plant wizard
  const handleCreateCustomPlant = (e: FormEvent) => {
    e.preventDefault();
    if (!newPlantName.trim()) {
      triggerToast("Lütfen geçerli bir bitki adı giriniz.", "warning");
      return;
    }

    const customId = `plant-${Date.now()}`;
    const plantObj: Plant = {
      id: customId,
      name: newPlantName,
      scientific: newPlantType === "Ağaç" ? "Meyve / Ağaç Formasyonu" : "Yıllık Sebze Kültürü",
      field: `${newPlantField} · Sensör #${Math.floor(Math.random() * 20 + 20)}`,
      moisture: newPlantMoisture,
      targetRange: `${newPlantMoisture - 10}%–${newPlantMoisture + 10}%`,
      isTree: newPlantType === "Ağaç",
      type: newPlantType,
      temp: 20 + Math.floor(Math.random() * 5),
      lastWatered: "Yeni eklendi",
      pH: 6.5,
      ec: 1.8,
    };

    setActivePlants((prev) => [...prev, plantObj]);
    setAddPlantOpen(false);
    triggerToast(`${newPlantName} bitkisi ${newPlantField} alanına başarıyla entegre edildi!`, "success");
    playRetroSynth();

    // Reset clean fields
    setNewPlantName("");
  };

  // Action: Simulate buying from MONAX referral store (commission-based model)
  const handleSimulateProductReferralPurchase = () => {
    if (!referralPopup) return;
    const prodName = referralPopup.name;
    setReferralPopup(null);

    playRetroSynth();
    
    setWarrantyPoints((prev) => {
      const nextValue = prev + 1;
      
      triggerToast(`🛍️ "${prodName}" başarıyla sipariş edildi! Monax komisyon kaydı işlendi ve +1 Garanti Puanı eklendi.`, "success");

      // Check milestones
      let milestoneTitle = "";
      let milestoneDesc = "";
      let milestoneIcon = "";
      let isMilestone = false;

      if (nextValue === 1) {
        milestoneTitle = "İlk Sipariş";
        milestoneDesc = "Sponsorlu mağazadan 1 ürün satın alındı.";
        milestoneIcon = "🛍️";
        isMilestone = true;
      } else if (nextValue === 3) {
        milestoneTitle = "Eko Destekçi";
        milestoneDesc = "Sponsorlu mağazadan toplam 3 ürün satın alındı (%12 indirim).";
        milestoneIcon = "🌱";
        isMilestone = true;
      } else if (nextValue === 5) {
        milestoneTitle = "Yeşil Yatırımcı";
        milestoneDesc = "Sponsorlu mağazadan toplam 5 ürün satın alındı.";
        milestoneIcon = "🧪";
        isMilestone = true;
      } else if (nextValue === 8) {
        milestoneTitle = "Süre Kahramanı";
        milestoneDesc = "8 siparişe ulaştınız! Garanti süresi uzamaya çok yakın.";
        milestoneIcon = "🚜";
        isMilestone = true;
      } else if (nextValue === 10) {
        milestoneTitle = "Garanti Fatihi";
        milestoneDesc = "10 siparişe ulaştınız! +1 Ay Akıllı Garanti kazandınız.";
        milestoneIcon = "🏆";
        isMilestone = true;

        setTimeout(() => {
          triggerToast("🎉 TEBRİKLER! 10 Ortaklı Satın Alıma ulaştınız. MONAX Akıllı Garanti Süreniz +1 Ay Uzatıldı!", "success");
        }, 1500);
      }

      if (isMilestone) {
        setRetroPopup({ title: milestoneTitle, desc: milestoneDesc, icon: milestoneIcon });
        setTimeout(() => {
          setRetroPopup(null);
        }, 5000);
      }

      // Update the progress and unlocked status of the achievements list
      setGameAchievements((prevAchievements) =>
        prevAchievements.map((ach) => {
          let updatedUnlocked = ach.unlocked;
          let updatedProgress = ach.progress;

          if (ach.id === "purchase_1") {
            updatedUnlocked = nextValue >= 1;
            updatedProgress = nextValue >= 1 ? 100 : 0;
          } else if (ach.id === "purchase_3") {
            updatedUnlocked = nextValue >= 3;
            updatedProgress = nextValue >= 3 ? 100 : Math.min((nextValue / 3) * 100, 100);
          } else if (ach.id === "purchase_5") {
            updatedUnlocked = nextValue >= 5;
            updatedProgress = nextValue >= 5 ? 100 : Math.min((nextValue / 5) * 100, 100);
          } else if (ach.id === "purchase_8") {
            updatedUnlocked = nextValue >= 8;
            updatedProgress = nextValue >= 8 ? 100 : Math.min((nextValue / 8) * 100, 100);
          } else if (ach.id === "purchase_10") {
            updatedUnlocked = nextValue >= 10;
            updatedProgress = nextValue >= 10 ? 100 : Math.min((nextValue / 10) * 100, 100);
          }

          return { ...ach, unlocked: updatedUnlocked, progress: updatedProgress };
        })
      );

      return nextValue;
    });
  };

  // Plant Data Configuration Dictionary for AI module updates
  const aiPlantData = {
    cilek: {
      scientific: "Fragaria × ananassa",
      emoji: "🍓",
      materials: [
        { name: "Çilek Fidesi", desc: "Sertifikalı · Albion çeşidi önerilir", type: "Zorunlu", color: "amber" },
        { name: "Damlama Sulama Borusu", desc: "Ø16mm · 2 GPH damlatıcılı", type: "Zorunlu", color: "blue" },
        { name: "Torf Toprağı (Organik)", desc: "pH 5.5 - 6.5 aralığı ideal", type: "Önerilir", color: "green" },
      ],
      fertilizers: [
        { name: "Organik Solucan Gübresi", desc: "%100 doğal aminoasit zengini", score: "★ 4.9", price: "280 ₺" },
        { name: "NPK 15-15-15 Dengeli Granül", desc: "Kök hücre kuvvetlendirici mineraller", score: "★ 4.8", price: "340 ₺" },
        { name: "Kalsiyum-Bor Makro Besin", desc: "Çiçek ve meyve tutumu için kritik koruyucu", score: "★ 4.6", price: "410 ₺" },
      ]
    },
    elma: {
      scientific: "Malus domestica",
      emoji: "🍎",
      materials: [
        { name: "Bodur Elma Fidanı", desc: "M9 anaçlı saksılı Amasya çeşidi", type: "Zorunlu", color: "amber" },
        { name: "Derin Kazık Sabitleyici", desc: "Fidanın dik durması için gergi teli", type: "Zorunlu", color: "blue" },
        { name: "Killi Tınlı Orman Toprağı", desc: "Gelişmiş kılcal kök besleyici katman", type: "Önerilir", color: "green" },
      ],
      fertilizers: [
        { name: "Yüksek Potasyumlu Meyve Gübresi", desc: "Tatlılık ve şeker oranını katlar", score: "★ 4.9", price: "480 ₺" },
        { name: "Çinko-Demir Şelatlı Karışım", desc: "Yaprak sararmalarını tamamen unutturur", score: "★ 4.7", price: "390 ₺" },
      ]
    },
    domates: {
      scientific: "Solanum lycopersicum",
      emoji: "🍅",
      materials: [
        { name: "Sırık Domates Tohumu/Fidesi", desc: "Yüksek mahsullü hibrit fidan", type: "Zorunlu", color: "amber" },
        { name: "Bağlama İpi & Sırık Profili", desc: "Sarkma önleyici dikey gerdirmeli hat", type: "Zorunlu", color: "blue" },
        { name: "Kokopit & Lif Karışımı", desc: "Havanın köklere kesintisiz gitmesini sağlar", type: "Önerilir", color: "green" },
      ],
      fertilizers: [
        { name: "NPK 10-52-10 Çiçek coşturucu", desc: "Fosfor yüklü başlangıç kiti", score: "★ 4.8", price: "310 ₺" },
        { name: "Sıvı Kalsiyum Nitrat Çözeltisi", desc: "Uç çürümesini (kırmızı kutu hatasını) engeller", score: "★ 4.9", price: "295 ₺" },
      ]
    },
    biber: {
      scientific: "Capsicum annuum",
      emoji: "🫑",
      materials: [
        { name: "Dolma Biber Fidesi", desc: "Ince kabuk tatlı meyve fidesi", type: "Zorunlu", color: "amber" },
        { name: "Hortum Dağıtıcı T-Konsept", desc: "Geniş taban alanı sökülebilir nipel", type: "Önerilir", color: "blue" },
      ],
      fertilizers: [
        { name: "Amonyum Sülfat %21 Azot", desc: "Yeşil gövdeyi canlandırıp yaprak döker", score: "★ 4.7", price: "240 ₺" },
        { name: "Magnezyum Sülfat Kristali", desc: "Fotosentezi hızlandıran magnezyum tuzu", score: "★ 4.8", price: "190 ₺" },
      ]
    },
    portakal: {
      scientific: "Citrus sinensis",
      emoji: "🍊",
      materials: [
        { name: "Washington Navel Fidanı", desc: "3 yaş aşılı narenciye fidan gövdesi", type: "Zorunlu", color: "amber" },
        { name: "Derin Kök Sulama Kazığı", desc: "Kumlu topraklarda derin suyu süzer", type: "Zorunlu", color: "blue" },
      ],
      fertilizers: [
        { name: "Narenciye İz Element Paketi", desc: "Bakır, çinko ve manganez içerir", score: "★ 4.9", price: "450 ₺" },
        { name: "Granül Humik & Fulvik Asit", desc: "Toprağı yumuşatıp narenciye ortamına katlar", score: "★ 4.8", price: "320 ₺" },
      ]
    }
  };

  const currentSelectionDetails = aiPlantData[selectedAIPlant];

  // Active Warnings Counter (Dynamically changes based on wateredTomato)
  const activeWarningsCount = wateredTomato ? 2 : 3;

  return (
    <div className="relative z-10 min-h-screen pb-24 font-body">
      
      {/* ── TOAST SYSTEM ── */}
      <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] flex flex-col gap-2.5 w-full max-w-[380px] px-4 pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className="pointer-events-auto flex items-center gap-3 glass border border-emerald-500/20 px-4 py-3.5 rounded-2xl text-[#eaf2ff] shadow-xl animate-fade-up"
          >
            <i
              className={`fa-solid ${
                t.type === "success"
                  ? "fa-circle-check text-emerald-400"
                  : t.type === "warning"
                  ? "fa-triangle-exclamation text-amber-400"
                  : "fa-circle-info text-[#60a5fa]"
              } text-base filter drop-shadow(0 0 4px currentColor)`}
            ></i>
            <span className="text-xs font-medium leading-relaxed">{t.message}</span>
          </div>
        ))}
      </div>

      {/* ── RETRO PIXEL ACHIEVEMENT POPUP ── */}
      <div
        className={`fixed top-6 right-6 z-[110] w-[320px] bg-[#1a1a1a] border-4 border-[#3a3a3a] p-3 shadow-2xl transition-all duration-500 rounded flex gap-3.5 items-center pointer-events-auto ${
          retroPopup ? "translate-x-0 opacity-100 scale-100" : "translate-x-[360px] opacity-0 scale-95"
        }`}
        style={{
          boxShadow: "0 10px 0 -5px rgba(0,0,0,0.6), inset 0 2px 0 1px rgba(255,255,255,0.1)",
        }}
      >
        <div className="w-10 h-10 bg-[#424242] border-2 border-[#151515] flex items-center justify-center text-xl shadow-[inset_-2px_-2px_0_#222,inset_2px_2px_0_#555]">
          {retroPopup?.icon}
        </div>
        <div className="flex-1 font-mono">
          <div className="text-[10px] text-[#55ff55] font-extrabold tracking-wide uppercase">Başarım Kazanıldı!</div>
          <div className="text-normal text-white font-bold leading-tight -mt-0.5">{retroPopup?.title}</div>
          <p className="text-[9px] text-[#b0b0b0] mt-0.5 leading-relaxed">{retroPopup?.desc}</p>
        </div>
      </div>

      {/* ── APP HEADER ── */}
      <header className="sticky top-0 z-40 bg-[#040e1c]/80 border-b border-white/5 backdrop-blur-md">
        <div className="max-w-md md:max-w-3xl lg:max-w-5xl mx-auto px-5 py-3.5 flex items-center justify-between">
          
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#0b1d38] to-[#004d30] border border-emerald-500/25 flex items-center justify-center shadow-[0_0_15px_rgba(0,229,122,0.15)]">
              <i className="fa-solid fa-leaf text-emerald-400 text-xs"></i>
            </div>
            <span className="logo-text text-xl">MONAX</span>
            <span className="pill pill-green bg-emerald-500/10 border border-emerald-500/25 px-2 py-0.5 rounded-full text-[9px] text-emerald-300 font-bold tracking-wide flex items-center gap-1.5 animate-pulse">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_#00e57a] inline-block"></span>
              CANLI
            </span>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setNotificationsOpen(true)}
              className="w-9 h-9 rounded-full bg-white/5 border border-white/10 flex items-center justify-center cursor-pointer relative hover:bg-white/10 duration-200"
            >
              <i className="fa-regular fa-bell text-white/50 text-xs"></i>
              <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-[#ff4757] border-2 border-[#020810] shadow-[0_0_6px_#ff4757]"></span>
            </button>
            <div
              onClick={() => {
                setEditNameField(userName);
                setEditEmailField(userEmail);
                setEditingProfile(false);
                setProfileOpen(true);
              }}
              className="w-9 h-9 rounded-full bg-gradient-to-br from-[#0b1d38] to-[#00a050] border-2 border-emerald-500/35 flex items-center justify-center cursor-pointer hover:border-emerald-400 duration-200"
            >
              <i className="fa-solid fa-user text-white text-[11px]"></i>
            </div>
          </div>

        </div>
      </header>

      {/* ── MAIN PAGES SWITCH CONTENT ── */}
      <main className="max-w-md md:max-w-3xl lg:max-w-5xl mx-auto px-4 pt-5 pb-16 relative">
        <AnimatePresence mode="wait">
        {/* ====================================
             PAGE: HOME (İstasyon Portalı)
           ==================================== */}
        {activeTab === "home" && (
          <motion.div
            key="home"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ type: "spring", stiffness: 380, damping: 30 }}
            className="space-y-5"
          >
            
            {/* Greeting */}
            <div>
              <p className="text-[11px] text-[#b4d2ff]/50 mb-1 font-semibold flex items-center gap-1.5">
                <i className="fa-solid fa-satellite-dish text-emerald-400"></i>
                Merkezi Hub Bağlı · 26 Mayıs 2026
              </p>
              <h1 className="text-2xl font-black font-display tracking-tight text-[#eaf2ff] leading-none">
                İyi Günler, <span className="shimmer-text">{userName.split(" ")[0]} Bey</span> 👋
              </h1>
              <p className="text-xs text-[#b4d2ff]/50 mt-1 leading-normal">
                Bugün {activePlants.length} bitkinizden {wateredTomato ? "hepsi ideal durumda!" : "1'i toprak nemi kritik seviyede, sulama bekliyor."}
              </p>
            </div>

            {/* TWO-COLUMN TABLET CONTROL HUB */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
              
              {/* Left Column (KPI Tracker & Realtime Sensors) */}
              <div className="md:col-span-7 space-y-5">
                
                {/* KPI Tracker Grid */}
                <div className="grid grid-cols-4 gap-2">
                  <div className="glass rounded-2xl p-3 text-center transition-all duration-300">
                    <div className="text-xl font-black text-emerald-400 tracking-tight font-display">{activePlants.length}</div>
                    <div className="text-[9px] text-[#b4d2ff]/40 font-bold uppercase mt-0.5">Aktif Bitki</div>
                  </div>
                  <div className="glass rounded-2xl p-3 text-center transition-all duration-300">
                    <div className={`text-xl font-black ${wateredTomato ? "text-emerald-400" : "text-[#ff4757]"} tracking-tight font-display`}>
                      {activeWarningsCount}
                    </div>
                    <div className="text-[9px] text-[#b4d2ff]/40 font-bold uppercase mt-0.5">Sistem Riski</div>
                  </div>
                  <div className="glass rounded-2xl p-3 text-center transition-all duration-300">
                    <div className="text-xl font-black text-[#60a5fa] tracking-tight font-display">
                      {wateredTomato ? "67%" : "53%"}
                    </div>
                    <div className="text-[9px] text-[#b4d2ff]/40 font-bold uppercase mt-0.5">Ort. Nem</div>
                  </div>
                  <div className="glass rounded-2xl p-3 text-center transition-all duration-300">
                    <div className="text-xl font-black text-amber-400 tracking-tight font-display">24°</div>
                    <div className="text-[9px] text-[#b4d2ff]/40 font-bold uppercase mt-0.5">Dış Ortam</div>
                  </div>
                </div>

              {/* Let's keep Left Column open so the sensors panel below falls inside it */}

            {/* ── CENTRAL SENSORS PANELS ── */}
            <div className="space-y-3.5">
              <div className="text-[10px] font-black font-display tracking-widest text-[#00e57a] uppercase">
                <i className="fa-solid fa-microchip mr-1.5"></i> CANLI İSTASYON VERİLERİ
              </div>

              {/* CARD 1: SERA DOMATESİ */}
              {activePlants.some((p) => p.id === "tomato") && (
                <div
                  className={`glass rounded-3xl p-4.5 border transition-all duration-1000 ${
                    wateredTomato ? "glass-ok shadow-[0_0_20px_rgba(0,229,122,0.08)] bg-emerald-500/[0.01]" : "glass-critical"
                  }`}
                >
                  {/* Tomato Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-11 h-11 rounded-2xl flex items-center justify-center text-lg border transition-all duration-1000 ${
                          wateredTomato ? "bg-emerald-500/10 border-emerald-500/25" : "bg-red-500/10 border-red-500/25"
                        }`}
                      >
                        <i
                          className={`fa-solid ${
                            wateredTomato ? "fa-circle-check text-emerald-400" : "fa-triangle-exclamation text-red-400"
                          } text-base ${!wateredTomato && "animate-pulse"}`}
                        ></i>
                      </div>
                      <div>
                        <h3 className="text-sm font-black text-white leading-snug">Sera Domatesi</h3>
                        <p className="text-[10px] text-[#b4d2ff]/40 flex items-center gap-1 mt-0.5">
                          <i className="fa-solid fa-location-dot text-[8px]"></i>
                          Sera A · Sensör #03
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="flex items-center gap-2 justify-end">
                        <span className="relative flex h-2 w-2">
                          <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${wateredTomato ? "bg-emerald-400" : "bg-red-400"} opacity-75`}></span>
                          <span className={`relative inline-flex rounded-full h-2 w-2 ${wateredTomato ? "bg-emerald-400 shadow-[0_0_6px_#00e57a]" : "bg-[#ff4757] shadow-[0_0_6px_#ff4757]"}`}></span>
                        </span>
                        <span className="text-[9px] font-black text-white/90 tracking-wide">ANLIK TELEMETRİ</span>
                      </div>
                      <span
                        className={`pill mt-1 inline-block text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          wateredTomato ? "bg-emerald-500/10 text-emerald-300 border border-emerald-500/20" : "bg-red-500/10 text-red-300 border border-red-500/20"
                        }`}
                      >
                        {wateredTomato ? "İDEAL" : "KRİTİK"}
                      </span>
                    </div>
                  </div>

                  {/* Moisture Section */}
                  <div className="mt-4 flex items-end justify-between">
                    <div>
                      <span className="text-[10px] text-[#b4d2ff]/40 flex items-center gap-1">
                        <i className="fa-solid fa-droplet text-sky-400 text-[8px]"></i>
                        Anlık Toprak Nemi
                      </span>
                      <div
                        className={`text-3xl font-black font-display tracking-tight leading-none mt-1 transition-all duration-1000 ${
                          wateredTomato ? "text-emerald-400" : "text-[#ff4757]"
                        }`}
                      >
                        %{wateredTomato ? "85" : "28"}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] text-[#b4d2ff]/30 block -mb-0.5">Hedef Aralık</span>
                      <span className="text-xs font-bold text-white/50">%65 – %85</span>
                    </div>
                  </div>

                  {/* Dynamic Progress Bar */}
                  <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden mt-3">
                    <div
                      className={`h-full rounded-full transition-all duration-[1500ms] ${
                        wateredTomato ? "bg-gradient-to-r from-emerald-500 to-[#00e57a]" : "bg-gradient-to-r from-red-600 to-[#ff4757]"
                      }`}
                      style={{ width: wateredTomato ? "85%" : "28%" }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-[9px] text-[#b4d2ff]/25 mt-1.5 font-bold">
                    <span>0%</span>
                    <span className={wateredTomato ? "text-emerald-400/60" : "text-red-400/60"}>
                      {wateredTomato ? "%85 — İdeal" : "%28 — Kritik Kuraklık"}
                    </span>
                    <span>100%</span>
                  </div>

                  {/* Tomato Central Warning Box (Umut's Bug Fix Area) */}
                  <div
                    className={`mt-3.5 p-3 rounded-xl border transition-all duration-[800ms] flex items-center gap-2.5 ${
                      wateredTomato
                        ? "bg-emerald-500/5 border-emerald-500/15 text-emerald-300 shadow-md shadow-emerald-500/[0.01]"
                        : "bg-red-500/5 border-red-500/15 text-red-300"
                    }`}
                  >
                    <i
                      className={`fa-solid ${
                        wateredTomato ? "fa-shield-halved text-emerald-400" : "fa-triangle-exclamation text-red-400 animate-pulse"
                      } text-sm`}
                    ></i>
                    <div className="flex-1">
                      <div className="text-[11px] font-black uppercase tracking-wide">
                        {wateredTomato ? "SULAMA TAMAMLANDI - İdeal Seviye" : "KRİTİK KURAKLIK TESPİT EDİLDİ"}
                      </div>
                      <div className="text-[10px] opacity-70 leading-normal mt-0.5">
                        {wateredTomato
                          ? "Sistem otomatik kapandı · Bir sonraki kontrol 6 saat sonra gerçekleştirilecektir."
                          : "Nem oranı alt sınırın altında! Toprakta kuraklık artıyor, damlatma vanasını derhal açın."}
                      </div>
                    </div>
                  </div>

                  {/* Tomato Secondary Sensor Info */}
                  <div className="grid grid-cols-4 gap-1.5 mt-3.5 pt-1.5 border-t border-white/5">
                    <div className="bg-white/2 rounded-lg py-1.5 text-center">
                      <div className="text-[8px] text-[#b4d2ff]/30 uppercase font-bold">Isı</div>
                      <div className="text-xs font-black text-[#eaf2ff]">22°C</div>
                    </div>
                    <div className="bg-white/2 rounded-lg py-1.5 text-center">
                      <div className="text-[8px] text-[#b4d2ff]/30 uppercase font-bold">Takip</div>
                      <div className="text-xs font-black text-[#eaf2ff] truncate">
                        {wateredTomato ? "Yeni sula" : "2g önce"}
                      </div>
                    </div>
                    <div className="bg-white/2 rounded-lg py-1.5 text-center">
                      <div className="text-[8px] text-[#b4d2ff]/30 uppercase font-bold">Toprak pH</div>
                      <div className="text-xs font-black text-[#eaf2ff]">{wateredTomato ? "6.4" : "6.2"}</div>
                    </div>
                    <div className="bg-white/2 rounded-lg py-1.5 text-center">
                      <div className="text-[8px] text-[#b4d2ff]/30 uppercase font-bold">Sıvı EC</div>
                      <div className="text-xs font-black text-[#eaf2ff]">{wateredTomato ? "1.7" : "1.8"}</div>
                    </div>
                  </div>

                  {/* Sula Action Valve Control (Umut interaction) */}
                  <button
                    onClick={handleWaterTomato}
                    disabled={wateringLoading || wateredTomato}
                    className={`mt-4 w-full border-0 py-3 rounded-xl font-bold text-xs uppercase cursor-pointer flex items-center justify-center gap-2 duration-300 absolute-none ${
                      wateredTomato
                        ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 disabled:opacity-100 cursor-not-allowed"
                        : "bg-gradient-to-r from-red-600 to-[#ff4757] text-white hover:shadow-lg hover:shadow-red-500/10"
                    }`}
                  >
                    <i
                      className={`fa-solid ${
                        wateringLoading
                          ? "fa-spinner fa-spin"
                          : wateredTomato
                          ? "fa-circle-check"
                          : "fa-faucet-drip"
                      }`}
                    ></i>
                    <span>
                      {wateringLoading
                        ? "Sistem devreye alınıyor..."
                        : wateredTomato
                        ? "Sulama Başarıyla Tamamlandı ✓"
                        : "Sistemi Aç / Sula"}
                    </span>
                    <i className="fa-solid fa-chevron-right text-[9px] ml-auto"></i>
                  </button>

                  <button
                    onClick={() => {
                      const tomatoPlant = activePlants.find((p) => p.id === "tomato");
                      if (tomatoPlant) {
                        setSelectedPlantDetails({
                          ...tomatoPlant,
                          moisture: wateredTomato ? 85 : 28,
                          pH: wateredTomato ? 6.4 : 6.2,
                          ec: wateredTomato ? 1.7 : 1.8,
                          lastWatered: wateredTomato ? "Yeni sulandı" : "2 gün önce"
                        });
                      }
                    }}
                    className="mt-2.5 w-full bg-white/5 hover:bg-white/10 text-white/85 py-2.5 rounded-xl border border-white/5 font-semibold text-xs flex items-center justify-center gap-1.5 duration-200 cursor-pointer"
                  >
                    <i className="fa-solid fa-chart-area"></i>
                    <span>Detay ve Grafikler</span>
                    <i className="fa-solid fa-arrow-right text-[8px] ml-auto text-white/30"></i>
                  </button>
                </div>
              )}

              {/* CARD 2: TARLA BIBERI */}
              {activePlants.some((p) => p.id === "pepper") && (
                <div className="glass rounded-3xl p-4.5 border border-[#00e57a]/5 bg-emerald-500/[0.005]">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-lg">
                        <i className="fa-solid fa-leaf text-emerald-400 text-base"></i>
                      </div>
                      <div>
                        <h3 className="text-sm font-black text-white leading-snug">Tarla Biberi</h3>
                        <p className="text-[10px] text-[#b4d2ff]/40 flex items-center gap-1 mt-0.5">
                          <i className="fa-solid fa-location-dot text-[8px]"></i>
                          Tarla B · Sensör #07
                        </p>
                      </div>
                    </div>
                     <div className="text-right font-mono">
                      <div className="flex items-center gap-2 justify-end">
                        <span className="relative flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400 shadow-[0_0_6px_#00e57a]"></span>
                        </span>
                        <span className="text-[9px] font-black text-white/50 tracking-wide">AKTİF</span>
                      </div>
                      <span className="pill mt-1 inline-block text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                        İDEAL
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 flex items-end justify-between">
                    <div>
                      <span className="text-[10px] text-[#b4d2ff]/40 flex items-center gap-1">
                        <i className="fa-solid fa-droplet text-sky-400 text-[8px]"></i>
                        Anlık Toprak Nemi
                      </span>
                      <div className="text-3xl font-black font-display tracking-tight leading-none mt-1 text-emerald-400">
                        %76
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] text-[#b4d2ff]/30 block -mb-0.5">Hedef Aralık</span>
                      <span className="text-xs font-bold text-white/50">%65 – %85</span>
                    </div>
                  </div>

                  <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden mt-3">
                    <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-[#00e57a]" style={{ width: "76%" }}></div>
                  </div>

                  <button
                    onClick={() => {
                      const pepperPlant = activePlants.find((p) => p.id === "pepper");
                      if (pepperPlant) {
                        setSelectedPlantDetails(pepperPlant);
                      }
                    }}
                    className="mt-4 w-full bg-white/5 hover:bg-white/10 text-white/85 py-2.5 rounded-xl border border-white/5 font-semibold text-xs flex items-center justify-center gap-1.5 duration-200 cursor-pointer"
                  >
                    <i className="fa-solid fa-chart-area"></i>
                    <span>Detay ve Grafikler</span>
                    <i className="fa-solid fa-arrow-right text-[8px] ml-auto text-white/30"></i>
                  </button>
                </div>
              )}

              {/* CARD 3: AMASYA ELMASI (TREE) */}
              {activePlants.some((p) => p.id === "apple") && (
                <div className="glass rounded-3xl p-4.5 border border-amber-500/15">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-center text-xl">
                        🍎
                      </div>
                      <div>
                        <h3 className="text-sm font-black text-white leading-snug">Amasya Elması <span className="text-[10px] text-amber-300 bg-amber-500/15 px-1.5 py-0.5 rounded ml-1">Meyve Ağacı</span></h3>
                        <p className="text-[10px] text-[#b4d2ff]/40 flex items-center gap-1 mt-0.5">
                          <i className="fa-solid fa-tree text-[8px] text-emerald-400"></i>
                          Bahçe C · Sensör #12
                        </p>
                      </div>
                    </div>
                     <div className="text-right font-mono">
                      <div className="flex items-center gap-2 justify-end">
                        <span className="relative flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400 shadow-[0_0_6px_#00e57a]"></span>
                        </span>
                        <span className="text-[9px] font-black text-white/50 tracking-wide">AĞAÇ UYUMLU</span>
                      </div>
                      <span className="pill mt-1 inline-block text-[9px] font-bold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20">
                        OPTİMAL
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 flex items-end justify-between">
                    <div>
                      <span className="text-[10px] text-[#b4d2ff]/40 flex items-center gap-1">
                        <i className="fa-solid fa-droplet text-sky-400 text-[8px]"></i>
                        Anlık Toprak Nemi
                      </span>
                      <div className="text-3xl font-black font-display tracking-tight leading-none mt-1 text-amber-400">
                        %55
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] text-[#b4d2ff]/30 block -mb-0.5">Ağaç Hedef</span>
                      <span className="text-xs font-bold text-white/50">%50 – %70</span>
                    </div>
                  </div>

                  <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden mt-3">
                    <div className="h-full rounded-full bg-gradient-to-r from-amber-500 to-amber-400" style={{ width: "55%" }}></div>
                  </div>

                  <div className="mt-4 p-3 bg-amber-500/[0.04] border border-amber-500/10 rounded-xl flex items-center gap-2.5 text-xs">
                    <i className="fa-solid fa-clock-rotate-left text-amber-400"></i>
                    <p className="text-[11px] text-amber-100 leading-normal">
                      Olgunlaşma evresi için nem korunuyor. Hasata tahmini 14 gün kaldı.
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      const applePlant = activePlants.find((p) => p.id === "apple");
                      if (applePlant) {
                        setSelectedPlantDetails(applePlant);
                      }
                    }}
                    className="mt-3 w-full bg-white/5 hover:bg-white/10 text-white/85 py-2.5 rounded-xl border border-white/5 font-semibold text-xs flex items-center justify-center gap-1.5 duration-200 cursor-pointer"
                  >
                    <i className="fa-solid fa-circle-info"></i>
                    <span>Ağaç Detay ve Grafikler</span>
                    <i className="fa-solid fa-arrow-right text-[8px] ml-auto text-white/30"></i>
                  </button>
                </div>
              )}

              {/* DYNAMIC COMPONENT: ANY CUSTOM/NEWLY REGISTERED PLANTS ADDED */}
              {activePlants.filter((p) => p.id !== "tomato" && p.id !== "pepper" && p.id !== "apple").map((p) => (
                <div key={p.id} className="glass rounded-3xl p-4.5 border border-emerald-500/10 animate-fade-up">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-xl">
                        {p.isTree ? "🌳" : "🍓"}
                      </div>
                      <div>
                        <h3 className="text-sm font-black text-white leading-snug">{p.name}</h3>
                        <p className="text-[10px] text-[#b4d2ff]/40 flex items-center gap-1 mt-0.5">
                          <i className="fa-solid fa-location-dot text-[8px]"></i>
                          {p.field}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1 justify-end">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        <span className="text-[9px] font-black text-white/50">BAĞLI STATÜ</span>
                      </div>
                      <span className="pill mt-1 inline-block text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                        İDEAL
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 flex items-end justify-between">
                    <div>
                      <span className="text-[10px] text-[#b4d2ff]/40">Anlık Toprak Nemi</span>
                      <div className="text-2xl font-black font-display mt-1 text-emerald-400">
                        %{p.moisture}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] text-[#b4d2ff]/30 block -mb-0.5">Hedef</span>
                      <span className="text-xs font-bold text-white/50">{p.targetRange}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-3">
                    <button
                      type="button"
                      onClick={() => triggerToast(`${p.name} verici kalibrasyonu tamamlandı.`, "success")}
                      className="w-full bg-emerald-500/5 hover:bg-emerald-500/10 text-emerald-300 py-2 rounded-xl text-[10px] font-extrabold flex items-center justify-center duration-200 border border-emerald-500/15 cursor-pointer"
                    >
                      Kalibre Et
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedPlantDetails(p)}
                      className="w-full bg-white/5 hover:bg-white/10 text-white/80 py-2 rounded-xl text-[10px] font-extrabold flex items-center justify-center duration-200 border border-white/5 cursor-pointer"
                    >
                      Grafikler
                    </button>
                  </div>
                </div>
              ))}

            </div>

          </div> {/* Close Left Column (md:col-span-7) */}

          {/* Right Column (md:col-span-5) for Gamification, Savings, and AI Assistant */}
          <div className="md:col-span-5 space-y-5">

            {/* Loyalty and Warranty Card (Akıllı Mağaza & Garanti Sistemi) */}
            <div className="glass border-[#00e57a]/20 rounded-3xl p-4.5 shadow-lg shadow-emerald-500/[0.01] hover:shadow-emerald-500/[0.03] duration-300 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-xs font-black font-display tracking-widest text-[#00e57a] uppercase mb-1 flex items-center gap-1.5">
                    <i className="fa-solid fa-basket-shopping"></i> MONAX Ortaklı Mağaza & Garanti
                  </h3>
                  <p className="text-[11px] text-white/75 font-semibold leading-tight">
                    Sponsorlu Satın Alımlarla Garanti Uzatın
                  </p>
                </div>
                <span className="bg-[#00e57a]/15 border border-[#00e57a]/25 px-2 py-0.5 rounded-full text-[9px] text-[#5fffa8] font-bold">
                  %12 Geri Ödeme
                </span>
              </div>

              {/* Progress Tracker Slider */}
              <div className="space-y-2 bg-[#020810]/40 p-3 rounded-2xl border border-white/5">
                <div className="flex justify-between text-[10px] font-bold">
                  <span className="text-[#b4d2ff]/60">Garanti Uzatma Kilidi (+1 Ay)</span>
                  <span className={`${warrantyPoints >= 10 ? "text-[#00e57a] font-black" : "text-amber-300"} font-mono`}>
                    {warrantyPoints >= 10 ? "Genişletildi (2 Yıl 1 Ay) ✓" : `${warrantyPoints} / 10 Alışveriş`}
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden border border-white/5 relative">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-[#00e57a] duration-[800ms] shadow-[0_0_12px_rgba(0,229,122,0.5)]"
                    style={{ width: `${Math.min((warrantyPoints / 10) * 100, 100)}%` }}
                  ></div>
                </div>
                <p className="text-[9.5px] text-[#b4d2ff]/40 leading-normal">
                  {warrantyPoints >= 10
                    ? "Tebrikler! İş ortaklarımızın mağazalarından 10 siparişinizi tamamlayarak cihazınızın 2 yıllık garanti süresini ücretsiz olarak 1 ay uzattınız!"
                    : `Sponsorlu mağazadan yapacağınız her alışverişte hem %12 tasarruf sağlar hem de cihazınızın garanti süresini uzatırsınız. Hediye garanti için ${10 - warrantyPoints} sipariş kaldı.`}
                </p>
              </div>

              {/* MINI STORE / MAĞAZA PAZARI */}
              <div className="space-y-2.5">
                <div className="text-[10px] text-[#b4d2ff]/50 font-black uppercase tracking-wider flex items-center justify-between">
                  <span>🛍️ Hızlı Sipariş Pazar Alanı</span>
                  <span className="text-[9px] text-[#00e57a] font-mono font-bold">Anlık Ödeme</span>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setReferralPopup({ name: "Sıvı Solucan Gübresi (1L)", price: 280, discount: 12, store: "Trendyol" })}
                    className="text-left bg-white/3 border border-white/5 rounded-xl p-2.5 hover:bg-emerald-500/[0.03] hover:border-emerald-500/20 duration-200 cursor-pointer w-full group"
                  >
                    <span className="text-base">🧪</span>
                    <h4 className="text-[10.5px] font-bold text-white leading-tight mt-1 group-hover:text-emerald-300 duration-150">Solucan Gübresi</h4>
                    <span className="text-[9px] text-amber-300 font-bold font-mono">280 ₺</span>
                    <span className="block text-[8px] text-[#b4d2ff]/30 text-[#b4d2ff]/40 font-semibold mt-0.5">+1 Garanti Puanı</span>
                  </button>

                  <button
                    onClick={() => setReferralPopup({ name: "NPK 15-15-15 Akıllı Gübre", price: 340, discount: 12, store: "Hepsiburada" })}
                    className="text-left bg-white/3 border border-white/5 rounded-xl p-2.5 hover:bg-emerald-500/[0.03] hover:border-emerald-500/20 duration-200 cursor-pointer w-full group"
                  >
                    <span className="text-base">🌱</span>
                    <h4 className="text-[10.5px] font-bold text-white leading-tight mt-1 group-hover:text-emerald-300 duration-150">NPK Mineralli Gübre</h4>
                    <span className="text-[9px] text-amber-300 font-bold font-mono">340 ₺</span>
                    <span className="block text-[8px] text-[#b4d2ff]/30 text-[#b4d2ff]/40 font-semibold mt-0.5">+1 Garanti Puanı</span>
                  </button>

                  <button
                    onClick={() => setReferralPopup({ name: "X-03 Yedek Nem Vericisi", price: 520, discount: 12, store: "Trendyol" })}
                    className="text-left bg-white/3 border border-white/5 rounded-xl p-2.5 hover:bg-emerald-500/[0.03] hover:border-emerald-500/20 duration-200 cursor-pointer w-full group"
                  >
                    <span className="text-base">📟</span>
                    <h4 className="text-[10.5px] font-bold text-white leading-tight mt-1 group-hover:text-emerald-300 duration-150">Yedek Nem Sensörü</h4>
                    <span className="text-[9px] text-amber-300 font-bold font-mono">520 ₺</span>
                    <span className="block text-[8px] text-[#b4d2ff]/30 text-[#b4d2ff]/40 font-semibold mt-0.5">+1 Garanti Puanı</span>
                  </button>

                  <button
                    onClick={() => setReferralPopup({ name: "Sıvı Kalsiyum Nitrat", price: 295, discount: 12, store: "Hepsiburada" })}
                    className="text-left bg-white/3 border border-white/5 rounded-xl p-2.5 hover:bg-emerald-500/[0.03] hover:border-emerald-500/20 duration-200 cursor-pointer w-full group"
                  >
                    <span className="text-base">💧</span>
                    <h4 className="text-[10.5px] font-bold text-white leading-tight mt-1 group-hover:text-emerald-300 duration-150">Sıvı Kalsiyum Nitrat</h4>
                    <span className="text-[9px] text-amber-300 font-bold font-mono">295 ₺</span>
                    <span className="block text-[8px] text-[#b4d2ff]/30 text-[#b4d2ff]/40 font-semibold mt-0.5">+1 Garanti Puanı</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Savings projection card */}
            <div className="glass glass-savings rounded-3xl p-4.5 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-sm font-black font-display tracking-tight text-white leading-tight">Yıllık Su & Gübre Tasarrufu</h2>
                  <p className="text-[10px] text-[#b4d2ff]/40">MONAX Akıllı Otomasyon Kıyası</p>
                </div>
                <div className="pill pill-green bg-emerald-500/15 border border-emerald-500/25 px-2 py-1 rounded-full text-[9px] text-[#5fffa8] uppercase font-bold tracking-wide">
                  <i className="fa-solid fa-arrow-trend-up mr-1 text-[8px]"></i> Tasarruf Entegre
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-2xl p-3">
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <i className="fa-solid fa-droplet text-xs text-emerald-400"></i>
                    <span className="text-[10px] font-semibold text-[#b4d2ff]/60">Ekolojik Su</span>
                  </div>
                  <div className="text-lg font-black text-emerald-400 font-display">%42 Kar</div>
                  <p className="text-[9px] text-emerald-400/60 leading-tight">124 Ton / Aylık Hafıza</p>
                </div>
                <div className="bg-amber-400/5 border border-amber-400/10 rounded-2xl p-3">
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <i className="fa-solid fa-wallet text-xs text-amber-400"></i>
                    <span className="text-[10px] font-semibold text-[#b4d2ff]/60">Nakit Tasarrufu</span>
                  </div>
                  <div className="text-lg font-black text-amber-400 font-display">3.450 ₺</div>
                  <p className="text-[9px] text-amber-400/60 leading-tight">Aylık Gübre / Su Hasılatı</p>
                </div>
              </div>
            </div>

            {/* ── AI ASSISTANT & RECOMMENDATIONS SYSTEM (Özgür & Umut Combined) ── */}
            <div className="space-y-3">
              <div className="text-[10px] font-black font-display tracking-widest text-[#00e57a] uppercase">
                <i className="fa-solid fa-wand-magic-sparkles mr-1.5"></i> YENİ BİTKİ / MODEL ASİSTANI
              </div>

              <div className="glass rounded-3xl p-4.5 border border-emerald-500/10 space-y-4">
                
                {/* Assistant Header */}
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-black text-white">Yapay Zeka Destekli Planlama</h3>
                    <p className="text-[10px] text-[#b4d2ff]/40 leading-tight">Yetiştirmek istediğiniz bitkiyi seçin</p>
                  </div>
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                    <i className="fa-solid fa-robot text-xs"></i>
                  </div>
                </div>

                {/* Plant selection scroll (Vegetables + Trees!) */}
                <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-white/5">
                  <button
                    onClick={() => setSelectedAIPlant("cilek")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 duration-200 border cursor-pointer ${
                      selectedAIPlant === "cilek"
                        ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-300"
                        : "bg-white/5 border-white/5 text-white/60 hover:text-white"
                    }`}
                  >
                    <span>🍓</span> Çilek
                  </button>
                  <button
                    onClick={() => setSelectedAIPlant("elma")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 duration-200 border cursor-pointer ${
                      selectedAIPlant === "elma"
                        ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-300"
                        : "bg-white/5 border-white/5 text-white/60 hover:text-white"
                    }`}
                  >
                    <span>🍎</span> Elma Ağacı
                  </button>
                  <button
                    onClick={() => setSelectedAIPlant("domates")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 duration-200 border cursor-pointer ${
                      selectedAIPlant === "domates"
                        ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-300"
                        : "bg-white/5 border-white/5 text-white/60 hover:text-white"
                    }`}
                  >
                    <span>🍅</span> Domates
                  </button>
                  <button
                    onClick={() => setSelectedAIPlant("biber")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 duration-200 border cursor-pointer ${
                      selectedAIPlant === "biber"
                        ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-300"
                        : "bg-white/5 border-white/5 text-white/60 hover:text-white"
                    }`}
                  >
                    <span>🫑</span> Biber
                  </button>
                  <button
                    onClick={() => setSelectedAIPlant("portakal")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 duration-200 border cursor-pointer ${
                      selectedAIPlant === "portakal"
                        ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-300"
                        : "bg-white/5 border-white/5 text-white/60 hover:text-white"
                    }`}
                  >
                    <span>🍊</span> Portakal Ağacı
                  </button>
                </div>

                {/* Chosen plant card diagnostics box */}
                <div className="bg-emerald-500/[0.03] border border-emerald-500/15 p-3.5 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="text-2xl">{currentSelectionDetails.emoji}</div>
                    <div>
                      <div className="text-normal font-black text-[#5fffa8]">
                        Seçilen: {selectedAIPlant === "cilek" ? "Çilek" : selectedAIPlant === "elma" ? "Elma Ağacı" : selectedAIPlant === "domates" ? "Domates" : selectedAIPlant === "biber" ? "Biber" : "Portakal Ağacı"}
                      </div>
                      <div className="text-[10px] text-emerald-400/60 font-mono italic">
                        {currentSelectionDetails.scientific}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-extrabold text-[#5fffa8]">%97 Karar Oranı</div>
                    <div className="text-[8px] text-[#b4d2ff]/40">MONAX Karar Motoru</div>
                  </div>
                </div>

                {/* 1. REQUIRED MATERIALS RECOMMENDATION (Özgür Feature 3) */}
                <div className="space-y-2">
                  <div className="text-[10px] text-[#b4d2ff]/50 font-bold uppercase flex items-center gap-1.5">
                    <i className="fa-solid fa-box-open text-amber-400"></i>
                    Gereken Malzemeler (Seçili Bitki için)
                  </div>
                  <div className="bg-white/2 rounded-2xl p-2.5 border border-white/5 divide-y divide-white/5">
                    {currentSelectionDetails.materials.map((m, idx) => (
                      <div key={idx} className="flex items-center justify-between py-2 first:pt-0 last:pb-0">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center center justify-center text-xs">
                            🔨
                          </div>
                          <div>
                            <div className="text-xs font-bold text-white/90">{m.name}</div>
                            <span className="text-[9px] text-[#b4d2ff]/40">{m.desc}</span>
                          </div>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[8px] font-bold ${
                          m.color === "amber" ? "bg-amber-500/10 text-amber-300" : "bg-sky-500/10 text-sky-300"
                        }`}>
                          {m.type}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2. SPONSORLU / KOMISYONLU GÜBRE ÖNERILERI (Özgür Referral Model) */}
                <div className="space-y-2">
                  <div className="text-[10px] text-[#b4d2ff]/50 font-bold uppercase flex items-center gap-1.5">
                    <i className="fa-solid fa-flask text-purple-400"></i>
                    AI Gübre ve Cihaz Önerileri (Link / Komisyon)
                  </div>
                  <div className="space-y-2">
                    {currentSelectionDetails.fertilizers.map((f, idx) => (
                      <div key={idx} className="bg-white/2 border border-white/5 rounded-2xl p-3 flex justify-between items-center gap-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center text-xs">
                            🧪
                          </div>
                          <div>
                            <div className="text-xs font-bold text-white/90">{f.name}</div>
                            <p className="text-[9px] text-[#b4d2ff]/40 leading-snug mt-0.5">{f.desc}</p>
                            <span className="text-[9px] text-purple-400 font-bold mt-1 inline-block">{f.score} • Monax Tavsiyeli</span>
                          </div>
                        </div>

                        {/* Referral buy buttons */}
                        <div className="text-right flex-shrink-0">
                          <button
                            onClick={() => setReferralPopup({ name: f.name, price: parseInt(f.price), discount: 12, store: "Trendyol" })}
                            className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 hover:text-white border border-emerald-500/35 px-2.5 py-1.5 rounded-lg text-[10px] font-black cursor-pointer duration-200 whitespace-nowrap block"
                          >
                            Al {f.price}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Add to Garden primary button (Umut Profile Button check) */}
                {selectedAIPlant === "cilek" && (
                  <button
                    onClick={handleAddStrawberry}
                    className="w-full bg-gradient-to-r from-emerald-600 to-[#00e57a] text-[#001402] border-0 py-3.5 rounded-2xl font-black text-xs uppercase cursor-pointer hover:shadow-lg hover:shadow-emerald-500/10 duration-200 flex items-center justify-center gap-2"
                  >
                    <i className="fa-solid fa-circle-plus text-xs"></i>
                    <span>Çilek Bahçeme Ekle</span>
                    <i className="fa-solid fa-arrow-right text-[10px] ml-auto"></i>
                  </button>
                )}
                {selectedAIPlant !== "cilek" && (
                  <button
                    onClick={() => {
                      const details = aiPlantData[selectedAIPlant];
                      const newObj: Plant = {
                        id: `plant-${Date.now()}`,
                        name: `${details.emoji} ${selectedAIPlant.toUpperCase()} Gelişmiş Modül`,
                        scientific: details.scientific,
                        field: "Sera A · Sensör #09",
                        moisture: 70,
                        targetRange: "60%-80%",
                        isTree: selectedAIPlant === "elma" || selectedAIPlant === "portakal",
                        type: (selectedAIPlant === "elma" || selectedAIPlant === "portakal") ? "Ağaç" : "Sebze",
                        temp: 22,
                        lastWatered: "Şimdi eklendi",
                        pH: 6.4,
                        ec: 1.8,
                      };
                      setActivePlants((prev) => [...prev, newObj]);
                      triggerToast(`${selectedAIPlant.toUpperCase()} bahçenize başarıyla entegre edildi!`, "success");
                      playRetroSynth();
                    }}
                    className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/25 py-3 rounded-2xl font-bold text-xs uppercase cursor-pointer duration-200"
                  >
                    İzleme Profilini Bahçeye Ekle
                  </button>
                )}

              </div>
            </div>

          </div> {/* Close Right Column (md:col-span-5) */}
        </div> {/* Close TWO-COLUMN TABLET CONTROL HUB Grid */}

          </motion.div>
        )}

        {/* ====================================
             PAGE: PLANTS (Tüm Bitkilerim)
           ==================================== */}
        {activeTab === "plants" && (
          <motion.div
            key="plants"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ type: "spring", stiffness: 380, damping: 30 }}
            className="space-y-5"
          >
            <div>
              <p className="text-[11px] text-[#b4d2ff]/50 mb-1 font-semibold uppercase tracking-wider flex items-center gap-1">
                <i className="fa-solid fa-seedling text-emerald-400"></i> Bitki Kütüphanesi
              </p>
              <h1 className="text-xl font-black font-display tracking-tight text-[#eaf2ff]">
                Kayıtlı Tarım Portföyü
              </h1>
              <p className="text-xs text-[#b4d2ff]/40 mt-0.5">Bahçenize bağlı ve planlanmış tüm tarımsal sensör düğümleri.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {activePlants.map((p) => (
                <div key={p.id} className="glass rounded-3xl p-4 flex gap-3.5 items-center">
                  <div className="w-11 h-11 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-xl">
                    {p.name.includes("Çilek") ? "🍓" : p.name.includes("Domates") ? "🍅" : p.name.includes("Biber") ? "🫑" : p.name.includes("Elma") ? "🍎" : "🌱"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-black text-white truncate">{p.name}</h3>
                    <p className="text-[10px] text-[#b4d2ff]/40 truncate">{p.scientific} · {p.field}</p>
                    <div className="flex items-center gap-1.5 mt-1">
                      <div className="w-20 h-1 rounded-full bg-white/5 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${p.moisture < 40 ? "bg-red-400" : "bg-emerald-400"}`}
                          style={{ width: `${p.moisture}%` }}
                        ></div>
                      </div>
                      <span className="text-[10px] font-bold text-white/60">Nem: %{p.moisture}</span>
                    </div>
                  </div>
                  <span className={`pill text-[10px] font-bold px-2.5 py-1 rounded-full ${
                    p.moisture < 40 ? "bg-red-500/10 text-red-300 border border-red-500/20" : "bg-emerald-500/10 text-emerald-300 border border-emerald-500/20"
                  }`}>
                    {p.moisture < 40 ? "Kritik" : "Normal"}
                  </span>
                </div>
              ))}
            </div>

            {/* Launch wizard form button */}
            <button
              onClick={() => setAddPlantOpen(true)}
              className="w-full border-1.5 border-dashed border-emerald-500/35 bg-emerald-500/5 hover:bg-emerald-500/10 text-emerald-300 font-black py-4 rounded-2xl text-xs uppercase cursor-pointer transition-all duration-200 flex items-center justify-center gap-2"
            >
              <i className="fa-solid fa-plus text-xs"></i>
              <span>Yeni Bitki Ekle</span>
            </button>
          </motion.div>
        )}

        {/* ====================================
             PAGE: ANALYSIS (Piksel Başarımlar & Detaylı Veriler)
           ==================================== */}
        {activeTab === "analysis" && (
          <motion.div
            key="analysis"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ type: "spring", stiffness: 380, damping: 30 }}
            className="space-y-5"
          >
            <div>
              <p className="text-[11px] text-[#b4d2ff]/50 mb-1 font-semibold uppercase tracking-wider flex items-center gap-1">
                <i className="fa-solid fa-chart-line text-emerald-400"></i> Analiz Pano
              </p>
              <h1 className="text-xl font-black font-display tracking-tight text-[#eaf2ff]">
                Gelişmiş Analitik Raporu
              </h1>
              <p className="text-xs text-[#b4d2ff]/40 mt-0.5">Sera anlık ölçüm dökümleri ve gamification başarıları.</p>
            </div>

            {/* ANALYSIS TWO-COLUMN GRID */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-start">
              
              {/* Left Column (System Alerts & Performance Chart) */}
              <div className="space-y-5 animate-fade-up">

                {/* ── 1. DETAYLI SISTEM UYARILARI (Umut'un İstemi!) ── */}
            <div className="space-y-2.5">
              <div className="text-[10px] font-black font-display tracking-widest text-[#00e57a] uppercase flex items-center gap-2">
                <i className="fa-solid fa-circle-exclamation text-amber-400"></i>
                Detaylı Sistem Uyarıları ({activeWarningsCount} Aktif Sensör Uyarısı)
              </div>

              <div className="space-y-2.5">
                {/* Warning 1: Domates Nem (Dynamically resolves on wateredTomato state!) */}
                {!wateredTomato ? (
                  <div className="glass border-red-500/20 bg-red-500/[0.02] p-3.5 rounded-2xl flex gap-3 items-center animate-fade-up">
                    <div className="w-9 h-9 rounded-xl bg-red-500/10 border border-red-500/25 flex items-center justify-center text-red-500 flex-shrink-0 animate-pulse">
                      <i className="fa-solid fa-droplet text-sm"></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center text-xs font-black text-red-100">
                        <span>Sera Domatesi — Kritik Kuraklık</span>
                        <span className="text-[9px] bg-red-500/20 text-red-300 font-bold px-1.5 py-0.5 rounded uppercase">KRİTİK</span>
                      </div>
                      <p className="text-[10px] text-red-300/60 leading-relaxed mt-0.5">
                        Toprak nemi %28 (ideal sınır altı). Damlatma sistemi kapalı. Solma riski mevcut, hemen sulama yapın.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="glass border-emerald-500/20 bg-emerald-500/[0.02] p-3.5 rounded-2xl flex gap-3 items-center animate-fade-up">
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-500 flex-shrink-0">
                      <i className="fa-solid fa-circle-check text-sm"></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center text-xs font-black text-emerald-100">
                        <span>Sera Domatesi — Nem Stabil</span>
                        <span className="text-[9px] bg-emerald-500/20 text-emerald-300 font-bold px-1.5 py-0.5 rounded uppercase">ÇÖZÜLDÜ ✓</span>
                      </div>
                      <p className="text-[10px] text-emerald-400/60 leading-relaxed mt-0.5">
                        Sulama yapıldı. Toprak nemi %85 seviyesinde dengeli. Su kiti otomatik dinlenme evresinde.
                      </p>
                    </div>
                  </div>
                )}

                {/* Warning 2: Biber Gübreleme Sınırı */}
                <div className="glass border-amber-500/25 bg-amber-500/[0.01] p-3.5 rounded-2xl flex gap-3 items-center">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-center text-amber-400 flex-shrink-0">
                    <i className="fa-solid fa-flask text-sm"></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center text-xs font-black text-amber-100">
                      <span>Tarla Biberi — Gübre Gecikmesi</span>
                      <span className="text-[9px] bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.5 rounded uppercase">GÜBRE UYARI</span>
                    </div>
                    <p className="text-[10px] text-amber-300/60 leading-relaxed mt-0.5">
                      Son gübreleme üzerinden 12 gün geçti (Hedef: 10 gün). Yarın sabah NPK 15-15-15 verilmesini öneririz.
                    </p>
                  </div>
                </div>

                {/* Warning 3: Elma Isı Seviyesi */}
                <div className="glass border-amber-500/25 bg-amber-500/[0.01] p-3.5 rounded-2xl flex gap-3 items-center">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-center text-amber-400 flex-shrink-0">
                    <i className="fa-solid fa-temperature-arrow-down text-sm"></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center text-xs font-black text-amber-100">
                      <span>Amasya Elması — Sıcaklık Düşüşü</span>
                      <span className="text-[9px] bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.5 rounded uppercase">IKLIM SEVİYE</span>
                    </div>
                    <p className="text-[10px] text-amber-300/60 leading-relaxed mt-0.5">
                      Bahçe dikey sıcaklığı gece 14°C'ye düştü (Hedef: 15°C+). Amasya Elması kök koruyucusunu izleyin.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Simulated Consumption Graph inside Analysis */}
            <div className="glass rounded-3xl p-4">
              <h3 className="text-xs font-black tracking-wider uppercase text-white mb-2">Haftalık Su Sarfiyat Grafiği (Litre)</h3>
              <div className="flex justify-between items-end h-24 gap-3 bg-[#020810]/40 p-3 rounded-2xl border border-white/5">
                <div className="flex-1 flex flex-col items-center gap-1 h-full">
                  <div className="w-full bg-[#60a5fa]/20 rounded-t-lg h-3/5"></div>
                  <span className="text-[8px] text-[#b4d2ff]/30">Pzt</span>
                </div>
                <div className="flex-1 flex flex-col items-center gap-1 h-full">
                  <div className="w-full bg-[#60a5fa]/20 rounded-t-lg h-4/5"></div>
                  <span className="text-[8px] text-[#b4d2ff]/30">Sal</span>
                </div>
                <div className="flex-1 flex flex-col items-center gap-1 h-full">
                  <div className="w-full bg-[#60a5fa]/20 rounded-t-lg h-2/5"></div>
                  <span className="text-[8px] text-[#b4d2ff]/30">Çar</span>
                </div>
                <div className="flex-1 flex flex-col items-center gap-1 h-full">
                  <div className="w-full bg-[#60a5fa]/20 rounded-t-lg h-4/5"></div>
                  <span className="text-[8px] text-[#b4d2ff]/30">Per</span>
                </div>
                <div className="flex-1 flex flex-col items-center gap-1 h-full">
                  <div className="w-full bg-emerald-500/40 rounded-t-lg h-3/5 shadow-[0_0_10px_rgba(0,e5,122,0.2)]"></div>
                  <span className="text-[8px] text-emerald-400">Cuma</span>
                </div>
                <div className="flex-1 flex flex-col items-center gap-1 h-full">
                  <div className="w-full bg-emerald-500/40 rounded-t-lg h-[45%] shadow-[0_0_10px_rgba(0,e5,122,0.2)]"></div>
                  <span className="text-[8px] text-emerald-400">Cmt</span>
                </div>
              </div>
            </div>

              </div> {/* Close Left Column (System Alerts & Consumption Chart) */}

              {/* Right Column (Gamification Retro Achievements) */}
              <div className="space-y-5 animate-fade-up">

                {/* ── GAMIFICATION: RETRO PIXEL TROPHIES PANELS ── */}
            <div className="space-y-3">
              <div className="text-[10px] font-black font-display tracking-widest text-[#00e57a] uppercase">
                <i className="fa-solid fa-award mr-1.5"></i> MAĞAZA SİPARİŞ KİLİTLERİ (Sadakat & Garanti)
              </div>

              <div className="grid grid-cols-2 gap-3">
                {gameAchievements.map((ach) => (
                  <div
                    key={ach.id}
                    className={`p-3.5 border rounded-2xl flex flex-col justify-between h-[120px] transition-all duration-300 ${
                      ach.unlocked
                        ? "bg-emerald-500/[0.03] border-emerald-500/20 shadow-sm"
                        : "bg-white/1 border-white/5 opacity-40"
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="text-2xl">{ach.icon}</div>
                      <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded ${
                        ach.unlocked ? "bg-emerald-500/15 text-emerald-300" : "bg-white/5 text-white/40"
                      }`}>
                        {ach.unlocked ? "✓ AÇIK" : "KİLİTLİ"}
                      </span>
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white">{ach.title}</h4>
                      <p className="text-[9px] text-[#b4d2ff]/50 leading-tight mt-0.5 truncate">{ach.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div> {/* Close Right Column (Gamification Retro Achievements) */}
        </div> {/* Close ANALYSIS TWO-COLUMN GRID */}

          </motion.div>
        )}

        {/* ====================================
             PAGE: SETTINGS (Umut Toggles check)
           ==================================== */}
        {activeTab === "settings" && (
          <motion.div
            key="settings"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ type: "spring", stiffness: 380, damping: 30 }}
            className="space-y-5"
          >
            <div>
              <p className="text-[11px] text-[#b4d2ff]/50 mb-1 font-semibold uppercase tracking-wider flex items-center gap-1">
                <i className="fa-solid fa-gear text-emerald-400"></i> Hesap & Ayarlar
              </p>
              <h1 className="text-xl font-black font-display tracking-tight text-[#eaf2ff]">
                Sistem Konfigürasyonu
              </h1>
              <p className="text-xs text-[#b4d2ff]/40 mt-0.5">Sera Merkezi cihaz parametreleri ve ortaklık modeli.</p>
            </div>

            {/* SETTINGS RESPONSIVE GRID LAYOUT */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-start">
              
              {/* Left Column (Profile & Core Toggles) */}
              <div className="space-y-5 animate-fade-up">

                {/* Profile badge details */}
            <div className="glass rounded-3xl p-4 flex gap-3.5 items-center">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#0b1d38] to-[#00a050] border border-emerald-500/40 flex items-center justify-center text-xl">
                👨‍🌾
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-black text-white leading-none">{userName}</h3>
                <p className="text-[10px] text-[#b4d2ff]/40 mt-1">{userEmail} • PRO Lisansı Aktif</p>
                <span className="pill pill-green bg-emerald-500/10 text-emerald-300 mt-1 inline-block text-[8px] font-bold px-1.5 py-0.5 rounded uppercase">
                  MONAX KURUCU VIP
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setEditNameField(userName);
                  setEditEmailField(userEmail);
                  setEditingProfile(true);
                  setProfileOpen(true);
                  triggerToast("Profil düzenleme modu açıldı.", "info");
                }}
                className="bg-white/5 hover:bg-white/10 text-white/90 border border-white/10 rounded-xl px-2.5 py-1.5 text-[10px] font-bold cursor-pointer transition-all duration-200"
              >
                Düzenle
              </button>
            </div>

            {/* List and Toggles */}
            <div className="glass rounded-3xl p-1 divide-y divide-white/5">
              
              <div 
                className="flex justify-between items-center px-4 py-3.5 cursor-pointer hover:bg-white/[0.02] duration-150"
                onClick={() => {
                  setSettingsNotif(!settingsNotif);
                  triggerToast(`Bildirimler ${!settingsNotif ? "AKTİF" : "KAPALI"} hale getirildi.`, "info");
                  playRetroSynth();
                }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <i className="fa-solid fa-bell text-xs"></i>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white/90">Kritik Anlık Bildirimler</div>
                    <p className="text-[9px] text-[#b4d2ff]/40 leading-tight">Anormal durumlarda anlık sesli SMS ve Toast</p>
                  </div>
                </div>
                <div
                  className={`w-10 h-5.5 rounded-full p-0.5 duration-200 flex items-center ${
                    settingsNotif ? "bg-emerald-500" : "bg-white/10"
                  }`}
                >
                  <div className={`w-4.5 h-4.5 rounded-full bg-white shadow-md duration-200 transform ${
                    settingsNotif ? "translate-x-4.5" : "translate-x-0"
                  }`}></div>
                </div>
              </div>

              <div 
                className="flex justify-between items-center px-4 py-3.5 cursor-pointer hover:bg-white/[0.02] duration-150"
                onClick={() => {
                  setSettingsAuto(!settingsAuto);
                  triggerToast(`Otomatik mod ${!settingsAuto ? "ETKİN" : "PASİF"} konuma getirildi.`, "info");
                  playRetroSynth();
                }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-sky-500/10 flex items-center justify-center text-sky-400">
                    <i className="fa-solid fa-robot text-xs"></i>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white/90">Otomatik Yapay Zeka Kapama</div>
                    <p className="text-[9px] text-[#b4d2ff]/40 leading-tight">Toprak ideal neme ulaşınca vanaları otomatik kilitle</p>
                  </div>
                </div>
                <div
                  className={`w-10 h-5.5 rounded-full p-0.5 duration-200 flex items-center ${
                    settingsAuto ? "bg-emerald-500" : "bg-white/10"
                  }`}
                >
                  <div className={`w-4.5 h-4.5 rounded-full bg-white shadow-md duration-200 transform ${
                    settingsAuto ? "translate-x-4.5" : "translate-x-0"
                  }`}></div>
                </div>
              </div>

              <div className="flex justify-between items-center px-4 py-3.5 hover:bg-white/[0.01] duration-150">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400">
                    <i className="fa-solid fa-hourglass-half text-xs"></i>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white/90">Sensör Güncelleme Frekansı</div>
                    <p className="text-[9px] text-[#b4d2ff]/40 leading-tight">Ölçüm döngü sıklığı</p>
                  </div>
                </div>
                
                <div className="relative">
                  <select
                    id="sensor-interval-select"
                    value={settingsInterval}
                    onChange={(e) => {
                      const nextVal = e.target.value;
                      setSettingsInterval(nextVal);
                      triggerToast(`Sensör frekansı ${nextVal} olarak değiştirildi.`, "success");
                      playRetroSynth();
                    }}
                    className="appearance-none bg-[#09182d] hover:bg-[#0c223f] text-emerald-300 border border-emerald-500/30 rounded-xl pl-3 pr-8 py-1.5 text-xs font-black focus:outline-none focus:ring-1 focus:ring-emerald-400 cursor-pointer duration-150"
                  >
                    <option value="1 Dakika" className="bg-[#030d1a] text-white">1 Dakika</option>
                    <option value="5 Dakika" className="bg-[#030d1a] text-white">5 Dakika</option>
                    <option value="15 Dakika" className="bg-[#030d1a] text-white">15 Dakika</option>
                    <option value="1 Saat" className="bg-[#030d1a] text-white">1 Saat</option>
                    <option value="6 Saat" className="bg-[#030d1a] text-white">6 Saat</option>
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-emerald-400 text-[8px]">
                    <i className="fa-solid fa-chevron-down"></i>
                  </div>
                </div>
              </div>

            </div>
          </div> {/* Close Left Column (Profile & Core Toggles) */}
 
           {/* Right Column (Support, Device Sync & Info) */}
           <div className="space-y-5 animate-fade-up">
 
             {/* Logout/Support */}
             <div className="glass rounded-3xl p-1 divide-y divide-white/5">
              <div
                onClick={() => {
                  setContractsModalOpen(true);
                  triggerToast("Sözleşmeler ve lisans bilgileri açıldı.", "success");
                  playRetroSynth();
                }}
                className="flex items-center justify-between px-4 py-3.5 cursor-pointer hover:bg-white/[0.02]"
              >
                <span className="text-xs font-medium text-white/80">📜 Lisanslama & Sözleşmeler</span>
                <i className="fa-solid fa-chevron-right text-[9px] text-white/20"></i>
              </div>
              <div
                onClick={() => {
                  setBluetoothModalOpen(true);
                  setBluetoothSearching(true);
                  triggerToast("Bluetooth taraması başlatıldı...", "info");
                  playRetroSynth();
                  setTimeout(() => {
                    setBluetoothSearching(false);
                    triggerToast("Merkezi Hub bağlantısı doğrulandı!", "success");
                    playRetroSynth();
                  }, 2200);
                }}
                className="flex items-center justify-between px-4 py-3.5 cursor-pointer hover:bg-emerald-500/[0.04]"
              >
                <span className="text-xs font-medium text-[#5fffa8]">🔗 Cihaz Bluetooth Eşleme Testi</span>
                <i className="fa-solid fa-wifi text-[10px] text-[#5fffa8]"></i>
              </div>
            </div>

            {/* System Details Footer */}
            <div className="text-center md:text-left text-[9px] text-[#b4d2ff]/20 space-y-0.5 pt-3 w-full">
              <div>MONAX AKILLI TARIM BULUT ÇEKİRDEĞİ V2.4</div>
              <div>Cihaz Kimliği: MNX-9372-L4 - Bluetooth 5.2</div>
            </div>

          </div> {/* Close Right Column (Support, Device Sync & Info) */}
        </div> {/* Close SETTINGS RESPONSIVE GRID LAYOUT */}

          </motion.div>
        )}
        </AnimatePresence>

      </main>

      {/* ── BOTTOM TAB NAVIGATION ── */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#040e1c]/95 border-t border-white/5 backdrop-blur-lg pb-safe-bottom">
        <div className="max-w-md md:max-w-3xl lg:max-w-5xl mx-auto flex">
          
          <button
            onClick={() => setActiveTab("home")}
            className={`flex-1 flex flex-col items-center py-3 gap-1 cursor-pointer bg-transparent border-0 duration-150 ${
              activeTab === "home" ? "text-emerald-400 font-extrabold" : "text-[#b4d2ff]/30 hover:text-white"
            }`}
          >
            <i className="fa-solid fa-house text-sm"></i>
            <span className="text-[9px] uppercase tracking-wider">İstasyon</span>
          </button>

          <button
            onClick={() => setActiveTab("plants")}
            className={`flex-1 flex flex-col items-center py-3 gap-1 cursor-pointer bg-transparent border-0 duration-150 ${
              activeTab === "plants" ? "text-emerald-400 font-extrabold" : "text-[#b4d2ff]/30 hover:text-white"
            }`}
          >
            <i className="fa-solid fa-leaf text-sm"></i>
            <span className="text-[9px] uppercase tracking-wider">Kütüphane</span>
          </button>

          {/* Special central big add button */}
          <div className="flex-1 flex justify-center relative -top-3">
            <button
              onClick={() => setAddPlantOpen(true)}
              className="w-13 h-13 rounded-full bg-gradient-to-br from-emerald-600 to-[#00e57a] border-4 border-[#020810] flex items-center justify-center text-[#011e03] shadow-lg shadow-emerald-500/30 hover:scale-105 active:scale-95 duration-150 cursor-pointer"
            >
              <i className="fa-solid fa-plus text-base font-black"></i>
            </button>
          </div>

          <button
            onClick={() => setActiveTab("analysis")}
            className={`flex-1 flex flex-col items-center py-3 gap-1 cursor-pointer bg-transparent border-0 duration-150 ${
              activeTab === "analysis" ? "text-emerald-400 font-extrabold" : "text-[#b4d2ff]/30 hover:text-white"
            }`}
          >
            <i className="fa-solid fa-chart-line text-sm"></i>
            <span className="text-[9px] uppercase tracking-wider">Analiz</span>
          </button>

          <button
            onClick={() => setActiveTab("settings")}
            className={`flex-1 flex flex-col items-center py-3 gap-1 cursor-pointer bg-transparent border-0 duration-150 ${
              activeTab === "settings" ? "text-emerald-400 font-extrabold" : "text-[#b4d2ff]/30 hover:text-white"
            }`}
          >
            <i className="fa-solid fa-gear text-sm"></i>
            <span className="text-[9px] uppercase tracking-wider">Ayarlar</span>
          </button>

        </div>
      </nav>

      {/* ===================================================================
           OVERLAYS, MODALS & SHIPS (Umut'un Pop-up Optimizasyonu İstemi)
         =================================================================== */}

      {/* 1. SHOP REFFERAL CHECKOUT COMMISSION DIALOG (Özgür & Umut) */}
      {referralPopup && (
        <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass border-emerald-500/30 max-w-[360px] w-full p-5 rounded-3xl space-y-4 animate-fade-up">
            
            <div className="flex gap-3.5 items-center">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-lg">
                🛍️
              </div>
              <div>
                <h3 className="text-sm font-black text-white leading-tight">MONAX Akıllı Pazar Güvencesi</h3>
                <span className="text-[10px] text-purple-300 bg-purple-500/10 px-1.5 py-0.5 rounded">
                  Ortaklık Link Yönlendirme
                </span>
              </div>
            </div>

            <p className="text-xs text-[#b4d2ff]/70 leading-relaxed">
              Bu satın alma işleminden:
              <br />
              <b className="text-emerald-300">• %12 Özel Komisyon İndirimi</b> kazanacaksınız.
              <br />
              <b className="text-[#a78bfa]">• +1 Puan Retro Başarım</b> elde edip cihaz garanti sürenizi uzatacaksınız.
              <br />
              <span className="text-[10px] block text-[#b4d2ff]/40 mt-1">
                MONAX, Hepsiburada/Trendyol ortak satışından %12 komisyon alır. Bu sayede yazılım modülünü fonlar.
              </span>
            </p>

            <div className="bg-[#020810]/60 p-3 rounded-2xl border border-white/5 space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-white/60">Ürün:</span>
                <span className="font-bold text-white">{referralPopup.name}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-white/60">Fiyat:</span>
                <span className="font-bold text-amber-300">{referralPopup.price} ₺</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-white/60">Ortaklık Bonusu:</span>
                <span className="font-bold text-emerald-400">-%{referralPopup.discount} Cihaz İndirimi</span>
              </div>
            </div>

            <div className="flex gap-2.5">
              <button
                onClick={() => setReferralPopup(null)}
                className="flex-1 bg-white/5 hover:bg-white/10 text-white font-semibold py-2.5 rounded-xl text-xs duration-200 cursor-pointer border-0"
              >
                Vazgeç
              </button>
              <button
                onClick={handleSimulateProductReferralPurchase}
                className="flex-1 bg-gradient-to-r from-emerald-600 to-[#00e57a] text-[#001402] font-black py-2.5 rounded-xl text-xs duration-200 cursor-pointer border-0 shadow-lg shadow-emerald-500/10"
              >
                Simüle Satın Al
              </button>
            </div>

          </div>
        </div>
      )}

      {/* 2. PROFILE DRAWER SHEETS */}
      {profileOpen && (
        <div className="fixed inset-0 z-[160] bg-black/60 backdrop-blur-sm flex justify-end" onClick={() => setProfileOpen(false)}>
          <div
            className="w-full max-w-[320px] bg-[#040e1c] border-l border-white/5 h-full p-5 space-y-5 shadow-2xl overflow-y-auto animate-fade-left"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-black text-white">Profil Ayrıntıları</h3>
              <button
                className="w-7 h-7 bg-white/5 border border-white/10 rounded-full flex items-center justify-center cursor-pointer"
                onClick={() => setProfileOpen(false)}
              >
                <i className="fa-solid fa-xmark text-white/50 text-xs"></i>
              </button>
            </div>

            {editingProfile ? (
              <div className="bg-white/2 border border-[#00e57a]/20 p-4 rounded-2xl space-y-3 shadow-inner">
                <div className="text-[10px] font-black text-[#5fffa8] uppercase tracking-widest flex items-center gap-1.5 mb-1">
                  <i className="fa-solid fa-user-pen"></i> Profil Bilgilerini Düzenle
                </div>
                
                <div className="space-y-1">
                  <label className="text-[9px] text-[#b4d2ff]/40 font-bold uppercase tracking-wider block">Ad Soyad</label>
                  <input
                    type="text"
                    value={editNameField}
                    onChange={(e) => setEditNameField(e.target.value)}
                    className="w-full bg-[#020810] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500/50"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-[#b4d2ff]/40 font-bold uppercase tracking-wider block">E-posta</label>
                  <input
                    type="email"
                    value={editEmailField}
                    onChange={(e) => setEditEmailField(e.target.value)}
                    className="w-full bg-[#020810] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500/50"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingProfile(false)}
                    className="flex-1 bg-white/5 hover:bg-white/10 text-white/70 font-bold py-2 rounded-xl text-[10px] uppercase border-0 cursor-pointer duration-200"
                  >
                    Vazgeç
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (!editNameField.trim()) {
                        triggerToast("Lütfen geçerli bir isim girin.", "warning");
                        return;
                      }
                      if (!editEmailField.trim() || !editEmailField.includes("@")) {
                        triggerToast("Lütfen geçerli bir e-posta girin.", "warning");
                        return;
                      }
                      setUserName(editNameField);
                      setUserEmail(editEmailField);
                      setEditingProfile(false);
                      triggerToast("Profil bilgileri başarıyla kaydedildi!", "success");
                      playRetroSynth();
                    }}
                    className="flex-1 bg-[#00e57a] hover:bg-[#00c569] text-[#001c0d] font-black py-2 rounded-xl text-[10px] uppercase border-0 cursor-pointer duration-200 shadow-md shadow-emerald-500/10"
                  >
                    Kaydet
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 bg-white/2 rounded-2xl border border-white/5">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#0b1d38] to-[#00a050] border-2 border-emerald-500/40 flex items-center justify-center text-3xl mx-auto shadow-md">
                  👨‍🌾
                </div>
                <h4 className="text-sm font-black text-white mt-2.5">{userName}</h4>
                <p className="text-[10px] text-[#b4d2ff]/40">{userEmail} • PRO</p>
              </div>
            )}

            <div className="space-y-3">
              <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest"><i className="fa-solid fa-trophy mr-1"></i> Başarılar & Ödüller</div>
              <div className="bg-white/2 rounded-2xl p-3 border border-white/5 space-y-2">
                <div className="flex justify-between items-center text-xs text-white/70">
                  <span>Toplam Tasarrufunuz:</span>
                  <span className="font-bold text-emerald-300">124 Ton Su / Ay</span>
                </div>
                <div className="flex justify-between items-center text-xs text-white/70">
                  <span>Maliyet Kazanımı:</span>
                  <span className="font-bold text-amber-300">3.450 ₺ / Ay</span>
                </div>
                <div className="flex justify-between items-center text-xs text-white/70">
                  <span>Sera Başarı Oranı:</span>
                  <span className="font-bold text-[#60a5fa]">{wateredTomato ? "100%" : "88%"}</span>
                </div>
              </div>
            </div>

            {!editingProfile && (
              <button
                type="button"
                onClick={() => {
                  setEditNameField(userName);
                  setEditEmailField(userEmail);
                  setEditingProfile(true);
                  triggerToast("Bilgileri güncelleme formu açıldı.", "info");
                }}
                className="w-full bg-white/5 hover:bg-white/10 text-white font-bold py-2.5 rounded-xl text-xs duration-200 border-0 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <i className="fa-solid fa-user-pen text-[11px] text-[#5fffa8]"></i>
                Bilgileri Güncelle
              </button>
            )}
          </div>
        </div>
      )}

      {/* 3. ALERTS & NOTIFICATIONS LOGS DRAWER */}
      {notificationsOpen && (
        <div className="fixed inset-0 z-[160] bg-black/60 backdrop-blur-sm flex justify-start" onClick={() => setNotificationsOpen(false)}>
          <div
            className="w-full max-w-[320px] bg-[#040e1c] border-r border-white/5 h-full p-5 space-y-4 shadow-2xl overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-black text-white">Anlık Uyarı & Sistem Günlüğü</h3>
              <button
                className="w-7 h-7 bg-white/5 border border-white/10 rounded-full flex items-center justify-center cursor-pointer"
                onClick={() => setNotificationsOpen(false)}
              >
                <i className="fa-solid fa-xmark text-white/50 text-xs"></i>
              </button>
            </div>

            <div className="space-y-2.5">
              <div className="p-3 bg-red-500/5 border border-red-500/10 rounded-xl leading-normal text-xs">
                <div className="flex justify-between text-red-300 font-bold mb-0.5">
                  <span>MNX-NODE-03</span>
                  <span>Şimdi</span>
                </div>
                <p className="text-[10px] text-red-200/60">
                  Sera Domatesi toprak nem seviyesi kritik kuru (%28).
                </p>
              </div>

              <div className="p-3 bg-[#0b1d38]/40 border border-[#60a5fa]/10 rounded-xl leading-normal text-xs">
                <div className="flex justify-between text-[#60a5fa] font-bold mb-0.5">
                  <span>MNX-AUTO-VALVE</span>
                  <span>3s önce</span>
                </div>
                <p className="text-[10px] text-sky-200/60">
                  Damlama emisyon kapakları test sinyali başarıyla çözüldü.
                </p>
              </div>

              <div className="p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-xl leading-normal text-xs">
                <div className="flex justify-between text-[#5fffa8] font-bold mb-0.5">
                  <span>MNX-SYS-HEALTH</span>
                  <span>1g önce</span>
                </div>
                <p className="text-[10px] text-emerald-200/60 font-medium">
                  Merkezi Hub batarya doluluk oranı %94 (Stabil - Solar Şarj).
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. ADD NEW CROP/PLANT MODAL FORM (WIZARD) */}
      {addPlantOpen && (
        <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateCustomPlant}
            className="glass border-emerald-500/20 max-w-[380px] w-full p-5 rounded-3xl space-y-4 animate-fade-up"
          >
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-black text-white">Yeni Tarım İstasyonu Ekle</h3>
              <button
                type="button"
                onClick={() => setAddPlantOpen(false)}
                className="w-7 h-7 bg-white/5 border border-white/10 rounded-full flex items-center justify-center cursor-pointer"
              >
                <i className="fa-solid fa-xmark text-white/50 text-xs"></i>
              </button>
            </div>

            <div className="space-y-3">
              
              <div>
                <label className="block text-[10px] text-[#b4d2ff]/40 uppercase font-bold mb-1">İstasyon Bitki Türü</label>
                <input
                  type="text"
                  required
                  placeholder="Ör: Bodrum Mandalinası, Marul"
                  value={newPlantName}
                  onChange={(e) => setNewPlantName(e.target.value)}
                  className="w-full bg-[#020810]/50 border border-white/10 rounded-xl px-3 py-2 text-xs text-white/90 focus:border-emerald-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] text-[#b4d2ff]/40 uppercase font-bold mb-1">Entegre Alan / Hub</label>
                <select
                  value={newPlantField}
                  onChange={(e) => setNewPlantField(e.target.value)}
                  className="w-full bg-[#020810]/50 border border-white/10 rounded-xl px-3 py-2 text-xs text-white/90 focus:border-emerald-500 outline-none"
                >
                  <option value="Sera A">Sera A (Salkım Islak)</option>
                  <option value="Tarla B">Tarla B (Dış Ortam)</option>
                  <option value="Bahçe C">Bahçe C (Meyvelik/Ağaçlar)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-[#b4d2ff]/40 uppercase font-bold mb-1">Bitki Kültürü Tasnifi</label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setNewPlantType("Sebze")}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold border cursor-pointer ${
                      newPlantType === "Sebze"
                        ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-300"
                        : "bg-transparent border-white/10 text-white/55"
                    }`}
                  >
                    🥗 Sebze
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewPlantType("Ağaç")}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold border cursor-pointer ${
                      newPlantType === "Ağaç"
                        ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-300"
                        : "bg-transparent border-white/10 text-white/55"
                    }`}
                  >
                    🌳 Ağaç Entegrasyonu
                  </button>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[10px] text-[#b4d2ff]/40 font-bold uppercase mb-1">
                  <span>İdeal Nem Eşiği</span>
                  <span className="text-[#5fffa8] font-black">%{newPlantMoisture}</span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="90"
                  value={newPlantMoisture}
                  onChange={(e) => setNewPlantMoisture(parseInt(e.target.value))}
                  className="w-full accent-emerald-400 cursor-pointer text-xs"
                />
              </div>

            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-[#00e57a] text-[#001402] border-0 rounded-xl font-extrabold text-xs uppercase cursor-pointer hover:shadow-lg hover:shadow-emerald-500/10 duration-250 flex items-center justify-center gap-1.5"
            >
              <i className="fa-solid fa-circle-check"></i>
              <span>İstasyonu Bahçeye Ekle</span>
            </button>

          </form>
        </div>
      )}

      {/* 5. INTERACTIVE DETAILED CHARTS & METERS MODAL (User Fix!) */}
      {selectedPlantDetails && (
        <div className="fixed inset-0 z-[150] bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass border-emerald-500/20 max-w-[500px] w-full p-5 rounded-3xl space-y-4 animate-fade-up relative overflow-hidden">
            {/* Ambient visual background glow inside the modal */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 blur-[80px] pointer-events-none rounded-full"></div>

            {/* Header */}
            <div className="flex justify-between items-start">
              <div className="flex gap-3">
                <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center text-2xl shadow-inner select-none">
                  {selectedPlantDetails.isTree ? "🌳" : selectedPlantDetails.id === "tomato" ? "🍅" : selectedPlantDetails.id === "pepper" ? "🫑" : "🌱"}
                </div>
                <div>
                  <h3 className="text-base font-black text-white leading-normal flex items-center gap-1.5">
                    {selectedPlantDetails.name}
                    <span className="text-[9px] bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 px-1.5 py-0.5 rounded font-black font-mono">
                      {selectedPlantDetails.type}
                    </span>
                  </h3>
                  <p className="text-[10px] text-white/50 italic font-mono mt-0.5">
                    {selectedPlantDetails.scientific} · {selectedPlantDetails.field}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPlantDetails(null)}
                className="w-8 h-8 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white border border-white/10 rounded-full flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-sm"></i>
              </button>
            </div>

            {/* Parameter Cards (Mini Dashboard metrics) */}
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-[#020810]/50 border border-white/5 p-2 rounded-2xl text-center">
                <span className="text-[8px] text-[#b4d2ff]/40 uppercase font-black block">Toprak Nemi</span>
                <span className="text-sm font-black text-sky-400 font-mono">%{selectedPlantDetails.moisture}</span>
                <span className="text-[8px] text-[#b4d2ff]/30 block mt-0.5 leading-none">Hedef {selectedPlantDetails.targetRange}</span>
              </div>
              <div className="bg-[#020810]/50 border border-white/5 p-2 rounded-2xl text-center">
                <span className="text-[8px] text-[#b4d2ff]/40 uppercase font-black block">Isı Değeri</span>
                <span className="text-sm font-black text-amber-300 font-mono">{selectedPlantDetails.temp}°C</span>
                <span className="text-[8px] text-[#b4d2ff]/30 block mt-0.5 leading-none">Termal Sensör</span>
              </div>
              <div className="bg-[#020810]/50 border border-white/5 p-2 rounded-2xl text-center">
                <span className="text-[8px] text-[#b4d2ff]/40 uppercase font-black block">pH / Sıvı EC</span>
                <span className="text-sm font-black text-emerald-300 font-mono">{selectedPlantDetails.pH} pH</span>
                <span className="text-[8px] text-[#b4d2ff]/30 block mt-0.5 leading-none">EC: {selectedPlantDetails.ec} mS/cm</span>
              </div>
            </div>

            {/* Chart Interactive Tabs */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-[#b4d2ff]/50 font-black uppercase tracking-wider flex items-center gap-1">
                  <i className="fa-solid fa-chart-line text-[#00e57a]"></i> 6 Saatlik Grafik Analizi
                </span>
                
                {/* Micro Tab Buttons */}
                <div className="flex gap-1 bg-white/5 p-0.5 rounded-xl border border-white/5">
                  <button
                    type="button"
                    onClick={() => setDetailChartTab("humidity")}
                    className={`text-[9px] font-bold px-2 py-1 rounded-lg transition-all duration-200 cursor-pointer ${
                      detailChartTab === "humidity" ? "bg-emerald-500/15 text-emerald-300 font-black shadow-sm" : "text-white/40 hover:text-white"
                    }`}
                  >
                    Nem
                  </button>
                  <button
                    type="button"
                    onClick={() => setDetailChartTab("temperature")}
                    className={`text-[9px] font-bold px-2 py-1 rounded-lg transition-all duration-200 cursor-pointer ${
                      detailChartTab === "temperature" ? "bg-emerald-500/15 text-emerald-300 font-black shadow-sm" : "text-white/40 hover:text-white"
                    }`}
                  >
                    Sıcaklık
                  </button>
                  <button
                    type="button"
                    onClick={() => setDetailChartTab("ph")}
                    className={`text-[9px] font-bold px-2 py-1 rounded-lg transition-all duration-200 cursor-pointer ${
                      detailChartTab === "ph" ? "bg-emerald-500/15 text-emerald-300 font-black shadow-sm" : "text-white/40 hover:text-white"
                    }`}
                  >
                    pH
                  </button>
                </div>
              </div>

              {/* Dynamic SVG / HTML custom chart render block */}
              <div className="bg-[#020810]/80 border border-white/5 p-3 rounded-2xl relative">
                {/* Horizontal reference values list */}
                <div className="absolute left-2.5 top-2 bottom-6 flex flex-col justify-between text-[8px] text-white/20 font-mono pointer-events-none">
                  <span>
                    {detailChartTab === "humidity" ? "100%" : detailChartTab === "temperature" ? "40°C" : "14 pH"}
                  </span>
                  <span>
                    {detailChartTab === "humidity" ? "50%" : detailChartTab === "temperature" ? "20°C" : "7 pH"}
                  </span>
                  <span>
                    {detailChartTab === "humidity" ? "0%" : detailChartTab === "temperature" ? "0°C" : "0 pH"}
                  </span>
                </div>

                {/* SVG Spline Area Chart */}
                <div className="h-32 pl-8 pr-2 relative">
                  {/* Grid lines in background */}
                  <div className="absolute inset-y-0 left-8 right-2 flex flex-col justify-between pointer-events-none opacity-20 py-2">
                    <div className="border-b border-dashed border-white/10 w-full h-0"></div>
                    <div className="border-b border-dashed border-white/10 w-full h-0"></div>
                    <div className="border-b border-dashed border-white/10 w-full h-0"></div>
                  </div>

                  {(() => {
                    const chartPoints = getChartPoints(selectedPlantDetails, detailChartTab);
                    const getX = (i: number) => 15 + i * 50;
                    const getY = (ptVal: number) => {
                      let pct = 0;
                      if (detailChartTab === "humidity") {
                        pct = ptVal / 100;
                      } else if (detailChartTab === "temperature") {
                        pct = ptVal / 40;
                      } else {
                        pct = ptVal / 14;
                      }
                      return 110 - pct * 90;
                    };

                    const pts = chartPoints.map((pt, i) => ({
                      x: getX(i),
                      y: getY(pt.val),
                      val: pt.val,
                      label: pt.label,
                    }));

                    // Build cubic Bezier curve path
                    let dPath = `M ${pts[0].x} ${pts[0].y}`;
                    for (let i = 0; i < pts.length - 1; i++) {
                      const p0 = pts[i];
                      const p1 = pts[i + 1];
                      const cp1_x = p0.x + 20;
                      const cp1_y = p0.y;
                      const cp2_x = p1.x - 20;
                      const cp2_y = p1.y;
                      dPath += ` C ${cp1_x} ${cp1_y}, ${cp2_x} ${cp2_y}, ${p1.x} ${p1.y}`;
                    }

                    // Build polygon Area closed path
                    const dArea = `${dPath} L ${pts[pts.length - 1].x} 115 L ${pts[0].x} 115 Z`;

                    // Decide theme coloring dynamically
                    const latestMoisture = selectedPlantDetails ? selectedPlantDetails.moisture : 50;
                    let strokeColor = "#00e57a"; 
                    let gradientId = "gradient-green";

                    if (detailChartTab === "humidity") {
                      if (latestMoisture < 40) {
                        strokeColor = "#ff4757"; // Alert Red
                        gradientId = "gradient-red";
                      } else if (latestMoisture < 65) {
                        strokeColor = "#ffb830"; // Warning Orange
                        gradientId = "gradient-orange";
                      }
                    } else if (detailChartTab === "temperature") {
                      const currentTemp = selectedPlantDetails ? selectedPlantDetails.temp : 22;
                      if (currentTemp > 30 || currentTemp < 15) {
                        strokeColor = "#ffb830";
                        gradientId = "gradient-orange";
                      } else {
                        strokeColor = "#3b82f6"; // Blue
                        gradientId = "gradient-blue";
                      }
                    } else if (detailChartTab === "ph") {
                      const currentPH = selectedPlantDetails ? selectedPlantDetails.pH : 6.8;
                      if (currentPH < 5.8 || currentPH > 7.5) {
                        strokeColor = "#ffb830";
                        gradientId = "gradient-orange";
                      } else {
                        strokeColor = "#a855f7"; // Violet
                        gradientId = "gradient-purple";
                      }
                    }

                    return (
                      <svg width="100%" height="100%" viewBox="0 0 280 120" preserveAspectRatio="none" className="overflow-visible relative z-10">
                        <defs>
                          <linearGradient id="gradient-red" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#ff4757" stopOpacity="0.45" />
                            <stop offset="100%" stopColor="#ff4757" stopOpacity="0.0" />
                          </linearGradient>
                          <linearGradient id="gradient-orange" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#ffb830" stopOpacity="0.45" />
                            <stop offset="100%" stopColor="#ffb830" stopOpacity="0.0" />
                          </linearGradient>
                          <linearGradient id="gradient-green" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#00e57a" stopOpacity="0.45" />
                            <stop offset="100%" stopColor="#00e57a" stopOpacity="0.0" />
                          </linearGradient>
                          <linearGradient id="gradient-blue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.45" />
                            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
                          </linearGradient>
                          <linearGradient id="gradient-purple" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#a855f7" stopOpacity="0.45" />
                            <stop offset="100%" stopColor="#a855f7" stopOpacity="0.0" />
                          </linearGradient>
                        </defs>

                        {/* Spline Area Fill */}
                        <path d={dArea} fill={`url(#${gradientId})`} />

                        {/* Spline Stroke line */}
                        <path
                          d={dPath}
                          fill="none"
                          stroke={strokeColor}
                          strokeWidth="2.5"
                          strokeLinecap="round"
                        />

                        {/* Interactive Circles / Tooltip display on hover */}
                        {pts.map((p, idx) => (
                          <g key={idx} className="group/dot cursor-pointer">
                            {/* Pulse background overlay */}
                            <circle
                              cx={p.x}
                              cy={p.y}
                              r="8"
                              fill={strokeColor}
                              fillOpacity="0.1"
                              className="opacity-0 group-hover/dot:opacity-100 duration-200"
                            />
                            {/* Solid outer ring */}
                            <circle
                              cx={p.x}
                              cy={p.y}
                              r="4"
                              fill="#020810"
                              stroke={strokeColor}
                              strokeWidth="2"
                            />
                            {/* Inner bullet */}
                            <circle
                              cx={p.x}
                              cy={p.y}
                              r="1.5"
                              fill={strokeColor}
                            />
                            {/* Custom SVG Tooltip */}
                            <g className="opacity-0 group-hover/dot:opacity-100 pointer-events-none duration-150 transition-all">
                              <rect
                                x={p.x - 22}
                                y={p.y - 25}
                                width="44"
                                height="17"
                                rx="4"
                                fill="#040e1c"
                                stroke={strokeColor}
                                strokeWidth="1"
                                className="shadow-lg"
                              />
                              <text
                                x={p.x}
                                y={p.y - 13}
                                textAnchor="middle"
                                fill="#ffffff"
                                fontSize="7"
                                fontWeight="black"
                                fontFamily="monospace"
                              >
                                {p.val}
                                {detailChartTab === "humidity" ? "%" : detailChartTab === "temperature" ? "°" : ""}
                              </text>
                            </g>
                          </g>
                        ))}
                      </svg>
                    );
                  })()}
                </div>

                {/* Horizontal Labels */}
                <div className="flex justify-between pl-8 pr-2 mt-1.5 text-[8px] text-[#b4d2ff]/30 font-bold font-mono">
                  {getChartPoints(selectedPlantDetails, detailChartTab).map((pt, idx) => (
                    <span key={idx} className="flex-1 text-center">{pt.label}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick action: Manuel Sulama Pulse Test */}
            <div className="bg-[#020810]/40 p-3 rounded-2xl border border-white/5 flex items-center justify-between gap-3">
              <div>
                <span className="text-[8px] text-[#b4d2ff]/40 uppercase font-black block">Akıllı Geri Bildirim</span>
                <p className="text-[10px] text-white/75 font-semibold leading-tight">
                  {selectedPlantDetails.moisture < 45 
                    ? "İstasyonda sulama ihlali var! Manuel can suyu verilsin mi?"
                    : "İstasyon dengeli çalışıyor. Ekipman testi yapılabilir."}
                </p>
                <span className="text-[8px] text-[#b4d2ff]/30 block mt-0.5">Son sulama: {selectedPlantDetails.lastWatered}</span>
              </div>
              <button
                type="button"
                onClick={() => handleWaterDetailPlant(selectedPlantDetails.id)}
                disabled={isWateringDetailPlant || selectedPlantDetails.moisture >= 85}
                className={`py-2 px-3.5 rounded-xl font-bold text-[10px] uppercase duration-200 whitespace-nowrap flex items-center gap-1.5 border-0 cursor-pointer ${
                  selectedPlantDetails.moisture >= 85
                    ? "bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 opacity-80 cursor-not-allowed"
                    : "bg-[#00e57a] hover:bg-[#00c569] text-[#001c0d] font-black shadow-md shadow-emerald-500/10"
                }`}
              >
                {isWateringDetailPlant ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin"></i>
                    Sulanıyor...
                  </>
                ) : selectedPlantDetails.moisture >= 85 ? (
                  "Neme Doygun ✓"
                ) : (
                  <>
                    <i className="fa-solid fa-faucet-drip"></i>
                    Bölgesel Sula
                  </>
                )}
              </button>
            </div>
            
            {/* Disclaimer footer */}
            <div className="text-center text-[8px] text-[#b4d2ff]/20 font-medium">
              MONAX Karar Mekanizması • Son Verici Paket Alımı: Az önce (%100 Sinyal Gücü)
            </div>
          </div>
        </div>
      )}

      {/* 6. INTERACTIVE BLUETOOTH PAIRING DIALOG (User Fix!) */}
      {bluetoothModalOpen && (
        <div className="fixed inset-0 z-[150] bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass border-emerald-500/20 max-w-[420px] w-full p-5 rounded-3xl space-y-4 animate-fade-up relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-sky-500/10 blur-[60px] pointer-events-none rounded-full"></div>
            
            {/* Header */}
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <i className="fa-solid fa-bluetooth text-sky-400 text-lg"></i>
                <h3 className="text-sm font-black text-white">Cihaz Bluetooth Eşleme Testi</h3>
              </div>
              <button
                type="button"
                onClick={() => setBluetoothModalOpen(false)}
                className="w-7 h-7 bg-white/5 hover:bg-white/10 text-white/60 border border-white/10 rounded-full flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            {/* Content Scanning or Active Connection */}
            {bluetoothSearching ? (
              <div className="py-8 text-center space-y-4">
                <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
                  <span className="absolute inset-0 rounded-full bg-sky-500/10 border border-sky-500/20 animate-ping"></span>
                  <span className="absolute inset-2 rounded-full bg-sky-500/20 border border-sky-500/30 animate-pulse"></span>
                  <div className="w-10 h-10 rounded-full bg-sky-500/25 flex items-center justify-center text-sky-400 text-sm font-black animate-spin duration-3000">
                    <i className="fa-solid fa-spinner"></i>
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-white">Çevresel Ağ Taraması Sürüyor...</p>
                  <p className="text-[10px] text-white/50 leading-relaxed max-w-[280px] mx-auto">
                    Kanal 41 frekansı üzerinden MONAX Akıllı Hub sinyal paketleri aranıyor. Lütfen bekleyin.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-emerald-500/5 border border-emerald-500/20 p-4 rounded-2xl flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-300">
                    <i className="fa-solid fa-circle-check text-lg"></i>
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-emerald-300">Merkezi Hub Bulundu & Eşleşti</h4>
                    <p className="text-[10px] text-white/60 mt-0.5 font-mono">ID: MNX-9372-L4 · Güçlü Bağlantı</p>
                  </div>
                </div>

                <div className="bg-[#020810]/50 border border-white/5 p-3.5 rounded-2xl space-y-2 font-mono text-[9px]">
                  <div className="flex justify-between text-white/40">
                    <span>Sinyal Seviyesi (RSSI)</span>
                    <span className="font-bold text-emerald-400">-54 dBm (Mükemmel)</span>
                  </div>
                  <div className="flex justify-between text-white/40">
                    <span>Prototip Modülü</span>
                    <span className="font-bold text-white/70">Bluetooth Low Energy 5.2</span>
                  </div>
                  <div className="flex justify-between text-white/40">
                    <span>Sinyal Frekansı</span>
                    <span className="font-bold text-white/70">2.480 GHz ISM Bandı</span>
                  </div>
                  <div className="flex justify-between text-white/40">
                    <span>Çevresel Verici Durumu</span>
                    <span className="font-bold text-emerald-400">%100 Paket Doğruluğu</span>
                  </div>
                </div>

                <div className="flex gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setBluetoothSearching(true);
                      triggerToast("Bluetooth taraması yeniden başlatıldı.", "info");
                      playRetroSynth();
                      setTimeout(() => {
                        setBluetoothSearching(false);
                        triggerToast("Yeniden test tamamlandı: Sinyal Kararlı.", "success");
                        playRetroSynth();
                      }, 1800);
                    }}
                    className="flex-1 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold py-2.5 rounded-xl text-[10px] uppercase duration-200 cursor-pointer"
                  >
                    Bağlantıyı Yeniden Test Et
                  </button>
                  <button
                    type="button"
                    onClick={() => setBluetoothModalOpen(false)}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-[#001c0d] font-black py-2.5 rounded-xl text-[10px] uppercase duration-200 border-0 cursor-pointer shadow-md"
                  >
                    Eşlemeyi Kapat
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 7. INTERACTIVE CONTRACTS & LICENSES DIALOG (User Fix!) */}
      {contractsModalOpen && (
        <div className="fixed inset-0 z-[150] bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass border-emerald-500/20 max-w-[460px] w-full p-5 rounded-3xl space-y-4 animate-fade-up relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 blur-[60px] pointer-events-none rounded-full"></div>
            
            {/* Header */}
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <span className="text-xl">📜</span>
                <h3 className="text-sm font-black text-white">Lisanslama & Sözleşmeler</h3>
              </div>
              <button
                type="button"
                onClick={() => setContractsModalOpen(false)}
                className="w-7 h-7 bg-white/5 border border-white/10 rounded-full flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            {/* Contracts Body scrollable */}
            <div className="max-h-[260px] overflow-y-auto pr-1.5 space-y-3.5 scrollbar-thin">
              <div className="space-y-1">
                <h4 className="text-[11px] font-black text-emerald-400 uppercase tracking-wider">1. MONAX Donanım Sözleşmesi</h4>
                <p className="text-[10px] text-white/70 leading-relaxed">
                  İlgili akıllı hub seti ve kablosuz toprak nem vericileri Ahmet Yılmaz adına "VIP Kurucu" statüsünde lisanslanmıştır. İki yıl kesintisiz donanım değişimi garantisi altındadır.
                </p>
              </div>

              <div className="space-y-1">
                <h4 className="text-[11px] font-black text-emerald-400 uppercase tracking-wider">2. %12 Özel Komisyon Ortaklığı</h4>
                <p className="text-[10px] text-white/70 leading-relaxed">
                  MONAX, Hepsiburada ve Trendyol pazar yerleri üzerinden gerçekleştireceğiniz organik gübre, akıllı vana aksesuarları ve mineral takviyelerinde %12 özel ortaklık indirimi/komisyon fonlaması sunar.
                </p>
              </div>

              <div className="space-y-1">
                <h4 className="text-[11px] font-black text-emerald-400 uppercase tracking-wider">3. Veri Güvenliği ve KVKK Taahhüdü</h4>
                <p className="text-[10px] text-white/70 leading-relaxed">
                  Sera topraklarında ölçülen anlık pH/nem paketleri ve vana çalışma logları yerel BLE veritabanında saklanır. Bulut omurgasına aktarılan veri paketleri uçtan uca şifrelidir ve üçüncü taraflarla paylaşılmaz.
                </p>
              </div>

              <div className="space-y-1">
                <h4 className="text-[11px] font-black text-emerald-400 uppercase tracking-wider">4. SaaS & PRO Abonelik Modeli</h4>
                <p className="text-[10px] text-white/70 leading-relaxed">
                  Bu cihaz hesabı ömür boyu sınırsız yapay zeka planlaması ve sınırsız verici bağlama hakkı sunan VIP PRO lisansı ile yetkilendirilmiştir. Ek bir aylık veya yıllık servis ücreti yansıtılmaz.
                </p>
              </div>
            </div>

            <div className="bg-[#020810]/40 p-3 rounded-2xl border border-white/5 text-[9px] text-[#b4d2ff]/40 leading-normal">
              MONAX, akıllı tarımda sürdürülebilirliği desteklemek üzere dijital lisans çerçevesine bağımlı kalır. Tüm hakları saklıdır.
            </div>

            <div className="pt-1">
              <button
                type="button"
                onClick={() => {
                  setContractsModalOpen(false);
                  triggerToast("Sözleşmeler onaylandı.", "success");
                  playRetroSynth();
                }}
                className="w-full bg-[#00e57a] hover:bg-[#00c569] text-[#001c0d] font-black py-2.5 rounded-xl text-xs uppercase duration-200 border-0 cursor-pointer shadow-md"
              >
                Okudum, Onaylıyorum
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
